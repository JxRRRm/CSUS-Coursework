package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;

public class PlayerRobot extends Robot {
	private static PlayerRobot myRobot;
	
	public PlayerRobot(int objSize, double locX, double locY, int objColor, int objHeading, int objSpeed,
			int objMaximumSpeed, int objMaxDmg, int objLastBaseReached) {
		super(objSize, locX, locY, objColor, objHeading, objSpeed, objMaximumSpeed, objMaxDmg, objLastBaseReached);
		// TODO Auto-generated constructor stub
	}

	public static PlayerRobot getRobot() {
		if (myRobot == null)
			myRobot = new PlayerRobot(20, 200.0, 200.0, ColorUtil.rgb(255, 0, 0), 0, 10, 50, 100, 1);
		return myRobot;
	}

}
