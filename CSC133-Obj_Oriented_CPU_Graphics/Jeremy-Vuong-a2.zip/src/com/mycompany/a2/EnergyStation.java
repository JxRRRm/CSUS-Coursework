package com.mycompany.a2;

public class EnergyStation extends Fixed {
	private int capacity;
	
	//constructor
	public EnergyStation(final int objSize, final double locX, final double locY, int objColor, int objCapacity) {
		super(objSize, locX, locY, objColor);
		this.capacity = objCapacity;

	}
	//getter
	public int getCapacity() {
		return capacity;
	}
	//drainCapacity();method to drain energy station's capacity
	public void drainCapacity() {
		this.capacity = 0;
	}
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " capacity=" + capacity;
		return parentDesc + myDesc;
	}

}