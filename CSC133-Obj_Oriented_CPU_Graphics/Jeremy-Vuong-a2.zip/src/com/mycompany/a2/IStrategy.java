package com.mycompany.a2;

public interface IStrategy {
	public void apply();
}
