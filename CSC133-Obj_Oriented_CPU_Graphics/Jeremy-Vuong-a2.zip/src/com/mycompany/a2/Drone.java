package com.mycompany.a2;

public class Drone extends Movable {
	//constructor
	public Drone(final int objSize, double locX, double locY, final int objColor, int objHeading, int objSpeed) {
		super(objSize, locX, locY, objColor, objHeading, objSpeed);
		// TODO Auto-generated constructor stub
	}
	

}
