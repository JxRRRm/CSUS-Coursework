package com.mycompany.a2;

public class Robot extends Movable implements ISteerable{
	private int steeringDirection = 0;
	private int maximumSpeed;
	private int energyLevel = 50; 
	private int energyConsumptionRate = 1;
	private int damageLevel = 0;
	private int lastBaseReached; 
	private final int maxDmg;

	//constructor
	public Robot(final int objSize, double locX, double locY, int objColor, int objHeading, 
					int objSpeed, int objMaximumSpeed, final int objMaxDmg, int objLastBaseReached) 
	{
		super(objSize, locX, locY, objColor, objHeading, objSpeed);
		this.maximumSpeed = objMaximumSpeed;
		this.maxDmg = objMaxDmg;
		this.lastBaseReached = objLastBaseReached;
		
	}
	
	
	//steerLeft();method set turn the steering wheel of the robot 5 degrees to the left
	public void steerLeft() {
		if (steeringDirection > -40)
			setSteeringDirection(steeringDirection -5);
	}
	
	//steerRight();method set turn the steering wheel of the robot 5 degrees to the right
	public void steerRight() {
		if (this.steeringDirection < 40)
		setSteeringDirection(steeringDirection + 5);
	}
	
	
	// getters 
	public int getLastBaseReached() {
		return lastBaseReached;
	}
	public int getMaximumSpeed() {
		return maximumSpeed;
	}
	public int getEnergyLevel() {
		return energyLevel;
	}
	public int getDamageLevel() {
		return damageLevel;
	}
	public int getMaxDmg() {
		return maxDmg;
	}
	public int getSteeringDirection() {
		return steeringDirection;
	}
	public int getEnergyConsumptionRate() {
		return energyConsumptionRate;
	}

	//setters
	public void setLastBaseReached(int newBaseReached) {
		this.lastBaseReached =  newBaseReached;
	}
	public void setEnergyLevel(int nrgLevel) {
		this.energyLevel = nrgLevel;
	}
	public void setDamageLevel(int dmgLevel) {
		this.damageLevel = dmgLevel;
	}
	public void setSteeringDirection(int newDirection) {
		if (newDirection < -40)
			this.steeringDirection = -40;
		else if (newDirection > 40)
			this.steeringDirection = 40;
		else 
			this.steeringDirection = newDirection;
	}
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " maxSpeed=" + maximumSpeed 
							+ " steeringDirection=" + getSteeringDirection()
							+ " energyLevel=" + getEnergyLevel()
							+ " damageLevel=" + getDamageLevel();
		return parentDesc + myDesc;
	}


	
}
