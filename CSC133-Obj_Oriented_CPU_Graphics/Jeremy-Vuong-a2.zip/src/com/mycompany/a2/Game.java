package com.mycompany.a2;

import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.Toolbar;
import java.util.Vector;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
public class Game extends Form {
	private GameWorld gw;
	private MapView mv; // new in A2
	private ScoreView sv; // new in A2
	private Vector<Button> buttonVector = new Vector<Button>();	
	
	public Game(){
		gw = new GameWorld(); // create “Observable” GameWorld
		mv = new MapView(); // create an “Observer” for the map
		sv = new ScoreView(); // create an “Observer” for the game/player-robot
		// state data
		gw.addObserver(mv); // register the map observer
		gw.addObserver(sv); // register the score observer
		
		// code here to create Command objects for each command,
		// add commands to side menu and title bar area, bind commands to keys, create
		// control containers for the buttons, add buttons to the control containers,
		// add commands to the buttons, and add control containers, MapView, and
		// ScoreView to the form
		
// commands
		
		Command accelerate = new GameCommand("Accelerate", gw);
		Command steerLeft = new GameCommand("Left", gw);
		Command changeStrat = new GameCommand("Change Strategies", gw);
		Command nprCol = new GameCommand("Collide with NPR", gw);
		Command baseCol = new GameCommand("Collide with Base", gw);
		Command eStationCol = new GameCommand("Collide with Energy Station", gw);
		Command droneCol = new GameCommand("Collide with Drone", gw);
		Command tick = new GameCommand("Tick", gw);
		Command brake = new GameCommand("Brake", gw);
		Command steerRight = new GameCommand("Right", gw);
		Command map = new GameCommand("Map", gw);

		
		//sidemenu
		Command exit = new SideMenuCommand("Exit", gw);
		Command about = new SideMenuCommand("About", gw);
		Command helpMenu = new SideMenuCommand("Help", gw);
		Command sound = new SideMenuCommand("Sound On", gw);
		
		Toolbar myToolbar = new Toolbar();
		setToolbar(myToolbar);
		myToolbar.setTitle("Robo-track Game");
		
		CheckBox soundToggle = new CheckBox("Sound");
		soundToggle.getAllStyles().setBgTransparency(255);
		soundToggle.setCommand(sound);
		soundToggle.setSelected(true);
		
		myToolbar.addCommandToSideMenu(accelerate);
		myToolbar.addComponentToSideMenu(soundToggle);
		myToolbar.addCommandToSideMenu(about);
		myToolbar.addCommandToSideMenu(exit);
		//add an “empty” item to right side of title bar area
		myToolbar.addCommandToRightBar(helpMenu);
		soundToggle.setSelected(true);
		
// buttons
		Button b1 = new Button();
		Button b2 = new Button();
		Button b3 = new Button();
		Button b4 = new Button();
		Button b5 = new Button();
		Button b6 = new Button();
		Button b7 = new Button();
		Button b8 = new Button();
		Button b9 = new Button();
		Button b10 = new Button();

		// add buttons to vector	
		buttonVector.add(b1);
		buttonVector.add(b2);
		buttonVector.add(b3);
		buttonVector.add(b4);
		buttonVector.add(b5);
		buttonVector.add(b6);
		buttonVector.add(b7);
		buttonVector.add(b8);
		buttonVector.add(b9);
		buttonVector.add(b10);
		// style buttons
		for (int i=0; i<buttonVector.size(); i++) 
		{  
		    Button button = buttonVector.elementAt(i); 
		    button.getAllStyles().setBgTransparency(255);
		    button.getAllStyles().setBgColor(ColorUtil.BLUE);
		    button.getAllStyles().setFgColor(ColorUtil.WHITE);
		    button.getAllStyles().setBorder(Border.createLineBorder(2,ColorUtil.BLACK));
		    button.getAllStyles().setPadding(Component.TOP, 4);
		    button.getAllStyles().setPadding(Component.BOTTOM, 4);
		    button.getAllStyles().setPadding(Component.LEFT, 2);
		    button.getAllStyles().setPadding(Component.RIGHT, 2);
		    button.getAllStyles().setAlignment(CENTER);
		}//end for
		// set button commands
		b1.setCommand(accelerate);
		b2.setCommand(steerLeft);
		b3.setCommand(changeStrat);
		b4.setCommand(nprCol);
		b5.setCommand(baseCol);
		b6.setCommand(eStationCol);
		b7.setCommand(droneCol);
		b8.setCommand(tick);
		b9.setCommand(brake);
		b10.setCommand(steerRight);

// containers
		// west
		Container wContainer = new Container(BoxLayout.y());
		wContainer.getAllStyles().setBgTransparency(50);
		wContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		wContainer.getAllStyles().setBorder(Border.createLineBorder(1,ColorUtil.GRAY));
		wContainer.getAllStyles().setPadding(Component.TOP, 350);
		wContainer.add(b1).add(b2).add(b3);
		// east
		Container eContainer = new Container(BoxLayout.y());
		eContainer.getAllStyles().setBgTransparency(50);
		eContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		eContainer.getAllStyles().setBorder(Border.createLineBorder(1,ColorUtil.GRAY));
		eContainer.getAllStyles().setPadding(Component.TOP, 350);
		eContainer.add(b9).add(b10);
		// north
		Container sContainer = new Container(BoxLayout.x());
		sContainer.getAllStyles().setBgTransparency(50);
		sContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		sContainer.getAllStyles().setBorder(Border.createLineBorder(1,ColorUtil.GRAY));
		sContainer.getAllStyles().setPadding(Component.LEFT, 350);
		sContainer.add(b4).add(b5).add(b6).add(b7).add(b8);
		// cemter
		// code here to query MapView’s width and height and set them as world’s width and height
		mv.setWidth(gw.getWidth());
		mv.setHeight(gw.getHeight());
		
// form		
		setLayout(new BorderLayout());
		this.add(BorderLayout.CENTER, mv).
			add(BorderLayout.SOUTH, sContainer).
			add(BorderLayout.NORTH, sv).
			add(BorderLayout.EAST, eContainer).
			add(BorderLayout.WEST, wContainer);
		this.setToolbar(myToolbar);
		
		// key listers
		this.addKeyListener('a', accelerate);
		this.addKeyListener('b', brake);
		this.addKeyListener('l', steerLeft);
		this.addKeyListener('r', steerRight);
		this.addKeyListener('e', eStationCol);
		this.addKeyListener('g', droneCol);
		this.addKeyListener('t', tick);
		this.addKeyListener('m', map);
		this.show();
		gw.init(); // initialize world
		
		
	}
}

