package com.mycompany.a2;

public class NonPlayerRobot extends Robot{
	private IStrategy curStrategy;
	private String strategyID;		//attack = 1 base = 2
	
	public NonPlayerRobot(int objSize, double locX, double locY, int objColor, int objHeading, int objSpeed,
			int objMaximumSpeed, int objMaxDmg, int objLastBaseReached) {
		super(objSize, locX, locY, objColor, objHeading, objSpeed, objMaximumSpeed, objMaxDmg, objLastBaseReached);
		// TODO Auto-generated constructor stub
	}


	public void setStrategy(IStrategy newStrategy) {
		// TODO Auto-generated method stub
		this.curStrategy = newStrategy;
	}


	public void invokeStrategy() {
		// TODO Auto-generated method stub
		this.curStrategy.apply();
	}
	
	public String getStrategyID() {
		return strategyID;
	}
	
	public void setStrategyID(String iD) {
		strategyID = iD;
	}
	
	//toString();method to return object description
		public String toString() {
			String parentDesc = super.toString();
			String myDesc = " Strategy=" + getStrategyID();
			return parentDesc + myDesc;
		}

}
