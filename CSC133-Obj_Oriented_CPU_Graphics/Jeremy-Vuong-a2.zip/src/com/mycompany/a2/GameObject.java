package com.mycompany.a2;
import java.lang.String;

import com.codename1.charts.util.ColorUtil;

public abstract class GameObject {
	
	private final int size;
	private double x, y;
	private int color;
	
//constructor
	public GameObject(final int objSize, double locX, double locY, int objColor) {
		// TODO Auto-generated constructor stub
		this.size = objSize;
		this.x = locX;
		this.y = locY;
		this.color = objColor;
	}

//getters
	public int getSize() {
		return size;
	}	
	
	public int getColor() {
		return color;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
	
//setters
	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	public void setColor(int newColor) {
		this.color = newColor;
	}

//toString();method to return object description	
	public String toString() {
		String desc = "loc=" + getX() + ","+ getY() 
						+ " color=[" 
						+ ColorUtil.red(color) + ","  
						+ ColorUtil.green(color) + ","  
						+ ColorUtil.blue(color) + "]" 
						+ " size=" + size;
		return desc;
	}

}

