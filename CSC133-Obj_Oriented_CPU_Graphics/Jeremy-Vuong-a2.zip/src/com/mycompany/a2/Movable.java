package com.mycompany.a2;

public class Movable extends GameObject {
	private int heading;
	private int speed;
	
	//constructor
	public Movable(final int objSize, double locX, double locY, int objColor, int objHeading, int objSpeed) 
	{
		super(objSize, locX, locY, objColor);
		this.heading = objHeading;
		this.speed = objSpeed;
	}
	
	
	
	//getters
	public int getSpeed() 
	{
		return speed;
	}
	//
	public int getHeading() 
	{
		return heading;
	}
	
	//setters
	public void setSpeed(int newSpeed) 
	{
		this.speed = newSpeed;
	}
	
	public void setHeading(int newHeading) 
	{
		if (newHeading > 360) 
		{
			newHeading = newHeading - 360;
		}
		else if (newHeading < 0)
		{
			newHeading = 360 + newHeading;
		}
		
		this.heading = newHeading;
	}
	
	//move();method to move object 
	public void move() {
		double theta = 90 - this.getHeading(); 
		
		
		Math.toRadians(theta);
		double deltaX = Math.cos(Math.toRadians(theta))*getSpeed(); 
		double deltaY = Math.sin(Math.toRadians(theta))*getSpeed();
		
		double newX = getX() + deltaX;
		double newY = getY() + deltaY;
		newX = Math.round(newX*10.0)/10.0;
		newY = Math.round(newY*10.0)/10.0;
		this.setX(newX);
		this.setY(newY);
	}
	
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " heading=" + getHeading() 
				+ " speed=" + getSpeed();
		return parentDesc + myDesc;
	}
	

}
