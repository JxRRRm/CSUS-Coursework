package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;
import java.util.Observable;
import java.util.Random;


public class GameWorld extends Observable {
	//game state data
	private int clockTicks = 0;
	private int livesRemaining = 3;
	private boolean sound; 
	//game world dimensions
	private final int width = 1024;
	private final int height = 768;
	//other game data
	private final int lastBase = 4;
	private final int robotCollisionDmg = 20;
	private final int droneCollisionDmg = robotCollisionDmg/2;
	
	// collection
	private GameObjectCollection gameObjectCollection = new GameObjectCollection();
	private IIterator myIter = getGameObjectCollection().getIterator();
	// random generated numbers
	private Random rand = new Random();					//rand
	private int randOne = randomInt();					//random number between 10 and 50; used for drone instantiation
	private int randTwo = randomInt();
	
	// objects
	private Base baseOne, baseTwo, baseThree, baseFour;				
	private PlayerRobot playerRobot;
	private NonPlayerRobot nprOne, nprTwo, nprThree;
	private Drone droneOne, droneTwo;
	private EnergyStation stationOne, stationTwo;
	
	public void init() {
		//code here to create the 
		  //initial game objects/setup 
		this.sound = true;
		baseOne = new Base(10, 200.0, 200.0, ColorUtil.rgb(0, 0, 255), 1);
		baseTwo = new Base(10, 200.0, 700.0, ColorUtil.rgb(0, 0, 255), 2);
		baseThree = new Base(10, 700.0, 700.0, ColorUtil.rgb(0, 0, 255), 3);
		baseFour = new Base(10, 700.0, 200.0, ColorUtil.rgb(0, 0, 255), 4);
		
		playerRobot = PlayerRobot.getRobot();
		
		/*Each NPR is to have an initial location which
		is “near” the first base, but not exactly at the first base; instead, each NPR should be at least
		several robot lengths away from the first base (baseOne.getX() + (40 * rand.nextInt(10)-4)) //(baseOne.getY() + (40 * rand.nextInt(10)-4))
		*/
		nprOne = new NonPlayerRobot(20, baseOne.getX() + (20 * (Math.round((rand.nextDouble()*(6) - 3)*10.0)/10.0)), 
				baseOne.getY() + (20 * ((Math.round((rand.nextDouble()*(6) - 3)*10.0)/10.0))), ColorUtil.rgb(255, 0, 0), 0, 10, 50, 300, 1);
		
		nprTwo = new NonPlayerRobot(20, baseOne.getX() + (20 * (Math.round((rand.nextDouble()*(6) - 3)*10.0)/10.0)), 
				baseOne.getY() + (20 * ((Math.round((rand.nextDouble()*(6) - 3)*10.0)/10.0))), ColorUtil.rgb(255, 0, 0), 0, 10, 50, 300, 1);
		
		nprThree = new NonPlayerRobot(20, baseOne.getX() + ((Math.round((rand.nextDouble()*(6) - 3)*10.0)/10.0)), 
				baseOne.getY() + (20 * ((Math.round((rand.nextDouble()*(6) - 3)*10.0)/10.0))), ColorUtil.rgb(255, 0, 0), 0, 10, 50, 300, 1);

		
		droneOne = new Drone(10 + rand.nextInt(41), randomDouble(getWidth()), randomDouble(getHeight()), 
								ColorUtil.rgb(255, 175, 175), rand.nextInt(360), 5 + rand.nextInt(11));
		droneTwo = new Drone(10 + rand.nextInt(41), randomDouble(getWidth()) + 0.0, randomDouble(getHeight()), 
								ColorUtil.rgb(255, 175, 175), rand.nextInt(360), 5 + rand.nextInt(11));

		stationOne = new EnergyStation(randOne, randomDouble(getWidth()), randomDouble(getHeight()), ColorUtil.rgb(0, 255, 0), randOne);
		stationTwo = new EnergyStation(randTwo, randomDouble(getWidth()), randomDouble(getHeight()), ColorUtil.rgb(0, 255, 0), randTwo);	
		
			
		//add objects into collection
		getGameObjectCollection().add(playerRobot);
		getGameObjectCollection().add(baseOne);
		getGameObjectCollection().add(baseTwo);
		getGameObjectCollection().add(baseThree);
		getGameObjectCollection().add(baseFour);
		
		getGameObjectCollection().add(nprOne);
		getGameObjectCollection().add(nprTwo);
		getGameObjectCollection().add(nprThree);
		
		getGameObjectCollection().add(droneOne);
		getGameObjectCollection().add(droneTwo);
		getGameObjectCollection().add(stationOne);
		getGameObjectCollection().add(stationTwo);
		
		nprOne.setStrategy(new AttackStrategy(nprOne, getGameObjectCollection()));
		nprOne.setStrategyID("Attack");
		nprTwo.setStrategy(new AttackStrategy(nprTwo, getGameObjectCollection()));
		nprTwo.setStrategyID("Attack");
		nprThree.setStrategy(new BaseStrategy(nprThree, getGameObjectCollection()));
		nprThree.setStrategyID("Base");
	}
	// additional methods here to 
	 // manipulate world objects and 
	 // related game state data 
		
	
//randomDouble();method to return rounded random double for drone location====================================|
	private double randomDouble(double dbl) 
	{
		double randomDouble;
		randomDouble = rand.nextDouble() * (dbl - 0.0) + 0.0;
		randomDouble = (Math.round(randomDouble*10.0)/10.0);
		return randomDouble;
	}//end randomDouble()
	
//randomInt();method to generate a random integer between 10 and 50===========================================|
	private int randomInt() 
	{
		int randomInt = 10 + rand.nextInt(41);
		return randomInt;
	}//end randomInt()
	
	
//	
	
//win();method to handle win condition========================================================================|
	public void win() {
		System.out.println("Game over, you win! Total time:  " + getClockTicks() + "\n");
		livesRemaining = 3;
		clockTicks = 0;
		exit();
		
	}
//died();method to handle robot sustaining too much damage or robot running out of energy=====================|
	public void died() 
	{
		myIter = getGameObjectCollection().getIterator();
		livesRemaining = livesRemaining- 1;
		
		if (getLivesRemaining() == 0) 
		{
			//reset game
			livesRemaining = 3;
			clockTicks = 0;
			setSound(true);
			this.setChanged();
			this.notifyObservers(this);
			System.out.println("Game over, you failed!”");
			exit();
		}
		else
		{
			//restart with new life
			while (myIter.hasNext()) {
				GameObject myObject = myIter.getNext();
				if (myObject instanceof PlayerRobot) {
					myObject.setX(baseOne.getX());
					myObject.setY(baseOne.getY());
					myObject.setColor(ColorUtil.rgb(255, 0, 0));
					((PlayerRobot) myObject).setDamageLevel(0);
					((PlayerRobot) myObject).setEnergyLevel(50);
					((PlayerRobot) myObject).setHeading(0);
					((PlayerRobot) myObject).setSpeed(10);
					((PlayerRobot) myObject).setLastBaseReached(1);
					((PlayerRobot) myObject).setSteeringDirection(0);
					this.setChanged();
					this.notifyObservers(this);
					System.out.println("You died! Restarting with new life...");
					break;
				}//end if
			}
		}
	}//end died()
	
//consumeEnergy();method to consume energy=======================================================================
	public void consumeEnergy() 
	{
		myIter = getGameObjectCollection().getIterator();
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				((PlayerRobot) myObject).setEnergyLevel(((PlayerRobot) myObject).getEnergyLevel()-((PlayerRobot) myObject).getEnergyConsumptionRate());
			}
		}
		

	}//end consumeEnergy()


//tick();method to increment clock ticks======================================================================|
	public void tick() 
	{
		// increment game clock
		clockTicks = clockTicks+1;
		
		myIter = getGameObjectCollection().getIterator();
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//check if player robot's energy level and damage level is sufficient to continue
				if ((((PlayerRobot) myObject).getEnergyLevel() > 0) && (((PlayerRobot) myObject).getDamageLevel() < ((PlayerRobot) myObject).getMaxDmg())) 
				{
					//update its heading
					((PlayerRobot) myObject).setHeading(((PlayerRobot) myObject).getHeading() + ((PlayerRobot) myObject).getSteeringDirection());
				}//end if
				else
				{
					died();		//robot dies because of insufficient energy or sustained too much damage
					
				}//end else
				break;
			}//end if
		}//end while

		// update drone headings, invoke npr strategies and move objects
		myIter = getGameObjectCollection().getIterator();
		while(myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof Drone) {
				((Drone) myObject).setHeading(((Drone) myObject).getHeading() + (-5 + rand.nextInt(6)));
			}
			if (myObject instanceof Movable) {
				((Movable) myObject).move();
				if (myObject instanceof NonPlayerRobot) {
					((NonPlayerRobot) myObject).invokeStrategy();
				}//end if
			}//end if
		}//end while
		
		// consume energy
		consumeEnergy();
		
		//check energy level after moving
		myIter = getGameObjectCollection().getIterator();
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//check if player robot's energy level and damage level is sufficient to continue
				if (((PlayerRobot) myObject).getEnergyLevel() < 1) 
					died();		//robot dies because of insufficient energy or sustained too much damage
				break;
			}//end if
		}//end while
		
		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("CLOCK HAS TICKED!\n");
	}//end tick()

//accelerate();method to accelerate===========================================================================
	public void accelerate() 
	{
		myIter = getGameObjectCollection().getIterator();		//iterator
		//increase player robot's speed
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//update player robot's speed
				((PlayerRobot) myObject).setSpeed(((Movable) myObject).getSpeed()+10);
				//cannot accelerate over max speed
				if (((PlayerRobot) myObject).getSpeed() > ((PlayerRobot) myObject).getMaximumSpeed())
					((PlayerRobot) myObject).setSpeed(((PlayerRobot) myObject).getMaximumSpeed());
				break;
			}//end if
		}//end while

		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("ROBOT HAS ACCELERATED!\n");							
	}//end accelerate()
	
//brake();method to brake=====================================================================================
	public void brake() 
	{
		myIter = getGameObjectCollection().getIterator();		//iterator
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//apply brakes
				((PlayerRobot) myObject).setSpeed(((PlayerRobot) myObject).getSpeed()-10);
				//cannot reduce speed lower than 0
				if (((PlayerRobot) myObject).getSpeed() < 0)
					((PlayerRobot) myObject).setSpeed(0);
				break;
			}//end if
		}//end while

		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("BRAKES ARE APPLIED\n");
	}//end brake()

//method to steer left=========================================================================================
	public void steerLeft() 
	{
		myIter = getGameObjectCollection().getIterator();		//iterator
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//invoke player robot's steerLeft method
				((PlayerRobot) myObject).steerLeft();
				break;
			}//end if
		}//end while
		
		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("STEERING WHEEL HAS TURNED LEFT\n");
	}//end steerLeft()
	
//steerRight();method to steer right===========================================================================
	public void steerRight() 
	{
		myIter = getGameObjectCollection().getIterator();		//iterator
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//invoke player robot's steerLeft method
				((PlayerRobot) myObject).steerRight();
				break;
			}//end if
		}//end while

		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("STEERING WHEEL HAS TURNED RIGHT\n");
	}//end steerRight()========================================================================================
	
//robotCollision();method to pretend that a robot collision has occurred=======================================
	public void robotCollision() 
	{	
		myIter = getGameObjectCollection().getIterator();		//iterator
		IIterator myIter2 = getGameObjectCollection().getIterator();		//iterator
		double nprX, nprY;
		
		//force collision with first npr in collection
		while (myIter.hasNext()) {
			GameObject npr = myIter.getNext();
			if (npr instanceof NonPlayerRobot) {
				 nprX = npr.getX();
				 nprY = npr.getY();
			
				 while (myIter2.hasNext()) {
					 GameObject player = myIter2.getNext();
					 if (player instanceof PlayerRobot) {
						 player.setX(nprX);
						 player.setY(nprY);
						 break;
					 }
				 }
				 break;
			}
		}
		
		
		myIter = getGameObjectCollection().getIterator();		//iterator
		myIter2 = getGameObjectCollection().getIterator();		//iterator
		
		while (myIter.hasNext()) {
			GameObject player = myIter.getNext();
			if (player instanceof PlayerRobot) {
				while (myIter2.hasNext()) {
					GameObject npr = myIter2.getNext();
					if (npr instanceof NonPlayerRobot) {
						//if this is the npr collided with
						if (player.getX() == npr.getX() && player.getY() == npr.getY()) {
							//player robot takes damage
							double maxDmg = ((PlayerRobot) player).getMaxDmg();
							double percent = (robotCollisionDmg + ((PlayerRobot) player).getDamageLevel())/maxDmg;
							double newSpeed = ((PlayerRobot) player).getSpeed() - (((PlayerRobot) player).getSpeed()*percent);
							//take damage
							((PlayerRobot) player).setDamageLevel(((PlayerRobot) player).getDamageLevel()+robotCollisionDmg);
							//update Speed
							((PlayerRobot) player).setSpeed((int) newSpeed);
							
							//check if sustained too much damage
							if (((PlayerRobot) player).getDamageLevel() >= (int)maxDmg) {
									died();
							}//end if
							else {
								// make color of robot lighter
								int r = ColorUtil.red(player.getColor())-25;
								int g = ColorUtil.green(player.getColor())-25;
								int b = ColorUtil.blue(player.getColor())-25;
								if (r<=0) {r=0;}
								if (g<=0) {g=0;}
								if (b<=0) {b=0;}
								int newColor = ColorUtil.rgb(r, g, b);
								player.setColor(newColor);
							}
							
							//npr takes damage
							maxDmg = ((NonPlayerRobot) npr).getMaxDmg();
							percent = (robotCollisionDmg + ((NonPlayerRobot) npr).getDamageLevel())/maxDmg;
							newSpeed = ((NonPlayerRobot) npr).getSpeed() - (((NonPlayerRobot) npr).getSpeed()*percent);
							//take damage
							((NonPlayerRobot) npr).setDamageLevel(((NonPlayerRobot) npr).getDamageLevel()+robotCollisionDmg);
							//update Speed
							((NonPlayerRobot) npr).setSpeed((int) newSpeed);
							
							/*check if npr sustained too much damage
							if (((NonPlayerRobot) npr).getDamageLevel() >= (int)maxDmg) {
									died();
							}//end if
							else {
							*/
								// make color of npr lighter
								int r = ColorUtil.red(npr.getColor())-15;
								int g = ColorUtil.green(npr.getColor())-15;
								int b = ColorUtil.blue(npr.getColor())-15;
								if (r<=0) {r=0;}
								if (g<=0) {g=0;}
								if (b<=0) {b=0;}
								int newColor = ColorUtil.rgb(r, g, b);
								npr.setColor(newColor);	
							break;
						}//end if
					}//end if	
				}//end while
				break;
			}//end if
		}//end while
		
		this.setChanged();
		this.notifyObservers(this);
		System.out.println("COLLISION WITH NON-PLAYER ROBOT HAS OCCURRED!\n");
	}//end robotCollision()
	
//baseCollision();method to handle base collision==============================================================
	public void baseCollision() {
		myIter = getGameObjectCollection().getIterator();		//iterator
		double firstX = 200.0, firstY = 200.0,				//first base location
				secondX = 200.0, secondY = 700.0,			//second base location
				thirdX = 700.0, thirdY = 700.0,				//third base location
				fouthX = 700.0, fouthY = 200.0;				//fouth base location
		int collidedBase;									//the base number of the base collided with
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//force collision with a base
				//first
				//myObject.setX(firstX);
				//myObject.setY(firstY);
				//second
				myObject.setX(secondX);
				myObject.setY(secondY);
				//third
				//((PlayerRobot) myObject).setLastBaseReached(2);
				//myObject.setX(thirdX);
				//myObject.setY(thirdY);
				//fourth
				//myObject.setX(fouthX);
				//myObject.setY(fouthY);
				
				//1
				if (myObject.getX() == firstX && myObject.getY()==firstY) {
					collidedBase = 1;
					if (collidedBase == ((PlayerRobot) myObject).getLastBaseReached()+1) {
						((PlayerRobot) myObject).setLastBaseReached(collidedBase);
					}
				}
				//2
				if (myObject.getX() == secondX && myObject.getY()==secondY) {
					collidedBase = 2;
					if (collidedBase == ((PlayerRobot) myObject).getLastBaseReached()+1) {
						((PlayerRobot) myObject).setLastBaseReached(collidedBase);
					}
				}
				//3
				if (myObject.getX() == thirdX && myObject.getY()==thirdY) {
					collidedBase = 3;
					if (collidedBase == ((PlayerRobot) myObject).getLastBaseReached()+1) {
						((PlayerRobot) myObject).setLastBaseReached(collidedBase);
					}
				}
				//if collided with last base (4), win
				if (myObject.getX() == fouthX && myObject.getY()==fouthY) {
					win();
				}
				break;
			}//end if
		}//end while

		this.setChanged();
		this.notifyObservers(this);
		System.out.println("COLLISION WITH A BASE!\n");
	}//end baseCollision()

//stationCollision();method to handle energy station collision ================================================
		public void stationCollision() 
		{ 
			myIter = getGameObjectCollection().getIterator();		//iterator
			IIterator myIter2 = getGameObjectCollection().getIterator();		//2nd iterator
			
			double X = 0;
			double Y = 0;										//location of energy station

			//get location of first energy station to force a collision
	    	while(myIter.hasNext()) {
				Object myObject = myIter.getNext();
				if (myObject instanceof EnergyStation) {
					if(((EnergyStation) myObject).getCapacity() != 0) {
						X = ((EnergyStation) myObject).getX();
						Y = ((EnergyStation) myObject).getY();
					
						while (myIter2.hasNext()) {
							GameObject player = myIter2.getNext();
							if (player instanceof PlayerRobot) {
								player.setX(X);
								player.setY(Y);
								break;
							}//end if
						}//end while
						break;
					}//end if
				}
	    	}//end while

			
	    	myIter = getGameObjectCollection().getIterator();		//get new iterator
	    	myIter2 = getGameObjectCollection().getIterator();		//2nd iterator
	    	
			while(myIter.hasNext()) {
				Object player = myIter.getNext();				//player robot
				if (player instanceof PlayerRobot) {
					while (myIter2.hasNext()) {
						GameObject station = myIter2.getNext();	//energy station
						if (station instanceof EnergyStation) {
							if (((PlayerRobot) player).getX() == ((EnergyStation) station).getX() && ((GameObject) player).getY() == ((EnergyStation) station).getY()
									&& ((EnergyStation) station).getCapacity() != 0) 
							{
								//fade energy station color
								int r = ColorUtil.red(((EnergyStation) station).getColor()) - 155;
								int g = ColorUtil.green(((EnergyStation) station).getColor()) - 155; 
								int b = ColorUtil.blue(((EnergyStation) station).getColor()) - 155; 
								if (r <= 0) {r = 0;}
								if (g <= 0) {g = 0;}
								if (b <= 0) {b = 0;}
								int newColor = ColorUtil.rgb(r, g, b);
								((EnergyStation) station).setColor(newColor);
							
								// absorb energy and drain station's capacity
								((PlayerRobot) player).setEnergyLevel( ((PlayerRobot) player).getEnergyLevel() + ((EnergyStation) station).getCapacity());
								((EnergyStation) station).drainCapacity();
						
								// destroy energy station collided with and generate new energy station
								int randomNumber = randomInt();
								EnergyStation newStation = new EnergyStation(randomNumber, randomDouble(getWidth()), randomDouble(getHeight()), 
														ColorUtil.rgb(0, 255, 0), randomNumber);
								getGameObjectCollection().add(newStation);
								break;
							}//end if
						}//end if
					}//end while
					break;
				}//end if
			}//end while
	
			
			this.setChanged();
			this.notifyObservers(this);
			System.out.println("COLLISION WITH ENERGY STATION!\n");
		}//end stationCollision()
		
	
//droneCollision();method to handle drone collision============================================================
		public void droneCollision() 
		{
			myIter = getGameObjectCollection().getIterator();		//iterator
			IIterator myIter2 = getGameObjectCollection().getIterator();		//2nd iterator
			double X, Y;										//drone location
			
			
			//get location of first energy station to force a collision
	    	while(myIter.hasNext()) {
				Object myObject = myIter.getNext();
				if (myObject instanceof Drone) {
					X = ((Drone) myObject).getX();
					Y = ((Drone) myObject).getY();
					
					while (myIter2.hasNext()) {
						GameObject player = myIter2.getNext();
						if (player instanceof PlayerRobot) {
							player.setX(X);
							player.setY(Y);
							break;
						}//end if
			    	}//end while
					break;
				}//end if
	    	}//end while
			
	    	
	    	myIter = getGameObjectCollection().getIterator();		//get new iterator
	    	myIter2 = getGameObjectCollection().getIterator();		//2nd iterator
	    	
			while(myIter.hasNext()) {
				Object player = myIter.getNext();				//player robot
				if (player instanceof PlayerRobot) {
					//initialize variables
					double maxDmg = ((PlayerRobot) player).getMaxDmg();
					double percent = (droneCollisionDmg + ((PlayerRobot) player).getDamageLevel())/maxDmg;
					double newSpeed = ((PlayerRobot) player).getSpeed() - (((PlayerRobot) player).getSpeed()*percent);
					
					while (myIter2.hasNext()) {
						GameObject drone = myIter2.getNext();	//energy station
						if (drone instanceof Drone) {
							if (((PlayerRobot) player).getX() == ((Drone) drone).getX() && ((PlayerRobot) player).getY() == ((Drone) drone).getY()) {
								//take damage
								((PlayerRobot) player).setDamageLevel(((PlayerRobot) player).getDamageLevel() + droneCollisionDmg);
								//update speed
								((PlayerRobot) player).setSpeed((int)newSpeed);
								//check if able to move
								if (((PlayerRobot) player).getDamageLevel() >= maxDmg) {
									died();
								}
								else {
									// make color of robot lighter
									int r = ColorUtil.red(((PlayerRobot) player).getColor())-15;
									int g = ColorUtil.green(((PlayerRobot) player).getColor())-15;
									int b = ColorUtil.red(((PlayerRobot) player).getColor())-15;
									if (r<0) {r=0;}
									if (g<0) {g=0;}
									if (b<0) {b=0;}
									int newColor = ColorUtil.rgb(r, g, b);
									((PlayerRobot) player).setColor(newColor);
								}//end else
								break;
							}//end if
						}//end if
					}//end while
				}//end if
			}//endwhile

			this.setChanged();
			this.notifyObservers(this);
			System.out.println("COLLISION WITH DRONE!\n");
		}//end droneCollision()


//map();method to display the current world description===========================================================
	public void map() 
	{
		myIter = getGameObjectCollection().getIterator();
		System.out.println("MAP: ");
		// display base description(s)
		while(myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof Base) {
				System.out.println("Base: " + myObject.toString()); 
			}
			else if (myObject instanceof PlayerRobot) {
				System.out.println("Player Robot: " + myObject.toString()); 
			}
			else if (myObject instanceof Robot) {
				System.out.println("NonPlayerRobot: " + myObject.toString()); 
			}
			else if (myObject instanceof Drone) {
				System.out.println("Drone: " + myObject.toString()); 
			}
			else if (myObject instanceof EnergyStation) {
				System.out.println("EnergyStation: " + myObject.toString()); 
			}
		}
		System.out.println();
	}//end map()

//exit();method to terminate the program============================================================================
		public void exit() 
		{
			System.out.println("EXITING GAME...");
			System.exit(0);
		}//end exit()===============================================================================================
		

//changeStrategies();method to change npr strategies
		public void changeStrategies(){
			myIter = getGameObjectCollection().getIterator();
			
			while (myIter.hasNext()) {
				GameObject myObject = myIter.getNext();
				if (myObject instanceof NonPlayerRobot) {
					if(((NonPlayerRobot) myObject).getStrategyID() == "Attack") {
						((NonPlayerRobot) myObject).setStrategy(new BaseStrategy((NonPlayerRobot)myObject, getGameObjectCollection()));
						((NonPlayerRobot) myObject).setStrategyID("Base");
					}
					else {
						((NonPlayerRobot) myObject).setStrategy(new AttackStrategy((NonPlayerRobot)myObject, getGameObjectCollection()));
						((NonPlayerRobot) myObject).setStrategyID("Attack");
					}
					((NonPlayerRobot) myObject).setLastBaseReached(((Robot) myObject).getLastBaseReached()+1);
				}
			}//end while
			
			this.setChanged();
			this.notifyObservers(this);
			System.out.println("NPR STRATEGY CHANGED!");
			
			//check if npr wins
			myIter = getGameObjectCollection().getIterator();
			while (myIter.hasNext()) {
				GameObject myObject = myIter.getNext();
				if (myObject instanceof NonPlayerRobot) {
					if (((NonPlayerRobot) myObject).getLastBaseReached()==lastBase) {
						System.out.println("Game over, a non-player robot wins!");
						System.exit(0);
					}
				}//end if
			}//end while
		}//end changeStrategies
		

// getters
		public boolean getSound() {
			return sound;
		}
		
		public int getClockTicks() {
			return clockTicks;
		}
		
		public int getLivesRemaining() {
			return livesRemaining;
		}


		public int getWidth() {
			return width;
		}

		public int getHeight() {
			return height;
		}
		
		public GameObjectCollection getGameObjectCollection() {
			return gameObjectCollection;
		}
		
		
// setters	
		public void setSound(boolean setting) {
				this.sound = setting;
				
				this.setChanged();
				this.notifyObservers(this);		
		}

		
		
//getters for scoreview
		public int getLastBaseReached() {
			myIter = gameObjectCollection.getIterator();

			while(myIter.hasNext()) {
				GameObject player = myIter.getNext();
				if (player instanceof PlayerRobot) {
					return ((PlayerRobot) player).getLastBaseReached();
				}
			}
			return 0;
		}
		
		public int getEnergyLevel() {
			myIter = gameObjectCollection.getIterator();

			while(myIter.hasNext()) {
				GameObject player = myIter.getNext();
				if (player instanceof PlayerRobot) {
					return ((PlayerRobot) player).getEnergyLevel();
				}
			}
			return 0;
		}
		
		public int getDamageLevel() {
			myIter = gameObjectCollection.getIterator();

			while(myIter.hasNext()) {
				GameObject player = myIter.getNext();
				if (player instanceof PlayerRobot) {
			 		return ((PlayerRobot) player).getDamageLevel();
				}
			}
			return 0;
		}

		
}//GameWorld
