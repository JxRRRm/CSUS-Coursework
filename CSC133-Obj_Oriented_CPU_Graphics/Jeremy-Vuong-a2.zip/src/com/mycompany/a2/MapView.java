package com.mycompany.a2;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.plaf.Border;

public class MapView extends Container implements Observer {
	private GameWorld gw;
	public MapView() {
		super();
		// TODO Auto-generated constructor stub
		this.getAllStyles().setBorder(Border.createLineBorder(2,ColorUtil.rgb(255, 0, 0)));
	}



	public void update (Observable o, Object arg) {
		// code here to call the method in GameWorld (Observable) that output the
		// game object information to the console
		gw = (GameWorld) arg;
		IIterator myIter = gw.getGameObjectCollection().getIterator();
		
		System.out.println("MAP: ");
		// display base description(s)
		while(myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof Base) {
				System.out.println("Base: " + myObject.toString()); 
			}
			else if (myObject instanceof PlayerRobot) {
				System.out.println("Player Robot: " + myObject.toString()); 
			}
			else if (myObject instanceof Robot) {
				System.out.println("NonPlayerRobot: " + myObject.toString()); 
			}
			else if (myObject instanceof Drone) {
				System.out.println("Drone: " + myObject.toString()); 
			}
			else if (myObject instanceof EnergyStation) {
				System.out.println("EnergyStation: " + myObject.toString()); 
			}
		}
		System.out.println();
		
	}
}
