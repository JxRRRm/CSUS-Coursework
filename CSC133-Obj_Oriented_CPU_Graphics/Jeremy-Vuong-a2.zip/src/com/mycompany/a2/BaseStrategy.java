package com.mycompany.a2;

import com.codename1.util.MathUtil;

public class BaseStrategy implements IStrategy{
	private NonPlayerRobot nonPlayerRobot;
	private GameObjectCollection collection;
	
	public BaseStrategy(NonPlayerRobot npr, GameObjectCollection gameObjects) {
		nonPlayerRobot = npr;
		collection = gameObjects;
	}

	public void apply() {
		double nprX = nonPlayerRobot.getX();
		double nprY = nonPlayerRobot.getY();
		double baseX = 0, baseY = 0;
		double a, b;
		double angleA;
		int angleB;

		IIterator myIter = collection.getIterator();
		
		//find next base for npr and get its location
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof Base) {
				if (nonPlayerRobot.getLastBaseReached() == ((Base) myObject).getSequenceNumber()+1) {
					baseX = myObject.getX();
					baseY = myObject.getY();
					break;
				}//end if
			}//end if
		}//end while	

		//calculate a and b 	
		a = baseX - nprX;
		b = baseY - nprY;
		
		// calculate ideal angle
		angleA = (90 - Math.toDegrees(MathUtil.atan2(a,b)));
		angleB = 90 - (int)(angleA);

		//set steering direction ??
		
		//set heading
		nonPlayerRobot.setHeading(angleB);
		//update strategy identifier
		nonPlayerRobot.setStrategyID("Base");
	}
		
		
		
}


