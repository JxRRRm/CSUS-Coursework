package com.mycompany.a2;

public class Fixed extends GameObject {
	
	//constructor
	public Fixed(final int objSize, final double locX, final double locY, int objColor) {
		super(objSize, locX, locY, objColor);
		// TODO Auto-generated constructor stub
	}

}
