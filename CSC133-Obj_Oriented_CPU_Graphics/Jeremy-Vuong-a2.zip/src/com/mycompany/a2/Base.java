package com.mycompany.a2;

public class Base extends Fixed {
	private int sequenceNumber;
	
	//constructor
	public Base(final int objSize, final double locX, final double locY, final int objColor, int objSequenceNumber) 
	{
		super(objSize, locX, locY, objColor);
		this.sequenceNumber = objSequenceNumber;
		// TODO Auto-generated constructor stub
	}
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " seqNum=" + sequenceNumber;
		return parentDesc + myDesc;
	}
	
	public int getSequenceNumber() {
		return sequenceNumber;
	}

}