package com.mycompany.a3;
import java.lang.String;
import java.util.Iterator;
import java.util.Vector;
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.geom.Point;

public abstract class GameObject implements ICollider{
	
	private final int size;
	private double x, y;
	private int color;
	private Vector<GameObject> collisionVector = new Vector<GameObject>();
//constructor
	public GameObject(final int objSize, double locX, double locY, int objColor) {
		// TODO Auto-generated constructor stub
		this.size = objSize;
		this.x = locX;
		this.y = locY;
		this.color = objColor;
	}
	
	//functions to alter/check the collision vector
	public void addToCollisionVector(GameObject otherObject) {
        collisionVector.add(otherObject);
    }

    public void removeFromCollisionVector(GameObject otherObject) {
        collisionVector.remove(otherObject);
    }

    public boolean isInCollisionVector(GameObject otherObject) {
        return collisionVector.contains(otherObject);
    }
	

//getters
	public int getSize() {
		return size;
	}	
	
	public int getColor() {
		return color;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
	
//setters
	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	public void setColor(int newColor) {
		this.color = newColor;
	}

//toString();method to return object description	
	public String toString() {
		String desc = "loc=" + getX() + ","+ getY() 
						+ " color=[" 
						+ ColorUtil.red(color) + ","  
						+ ColorUtil.green(color) + ","  
						+ ColorUtil.blue(color) + "]" 
						+ " size=" + size;
		return desc;
	}

	@Override
	public boolean collidesWith(GameObject otherObject) {
		Robot square;
		EnergyStation circle;
		Drone drone;
		Base base;
		//square-square
		if (otherObject instanceof Robot){
			int L1 = ((Robot) this).getLeftX();
			int R1 = ((Robot) this).getRightX();
			int T1 = ((Robot) this).getTopY();
			int B1 = ((Robot) this).getBottomY();
			int L2 = ((Robot) otherObject).getLeftX();
			int R2 = ((Robot) otherObject).getRightX();
			int T2 = ((Robot) otherObject).getTopY();
			int B2 = ((Robot) otherObject).getBottomY();
			if ( (R1 < L2) || (R2 < L1) || (T2 > B1) || (T1 > B2) )
				return false;
			else
				return true;
		//square-circle	
		} else if (otherObject instanceof EnergyStation) {
			
			square = (Robot) this;
			circle = (EnergyStation) otherObject;

			int lX = square.getLeftX();
			int rX = square.getRightX();
			int tY = square.getTopY();
			int bY = square.getBottomY();
			int cirX = circle.getCenterX();
			int cirY = circle.getCenterY();
			int radius = circle.getRadius();
			//first check corners
			// Find the closest corner
		    int dx = Math.min(Math.abs(cirX - lX), Math.abs(cirX - rX));
		    int dy = Math.min(Math.abs(cirY - tY), Math.abs(cirY - bY));
		    double d = Math.sqrt(dx * dx + dy * dy);

		    // Check if the closest corner is within the radius of the circle
		    if(d < radius) {
		    	return true;
		    }
			// if any side points intersect circle
			// left side (lX,tY) & (lX,bY)
		    d = distanceToSegment(cirX, cirY, lX, tY, lX, bY);
		    // right side (rX,tY) & (rX,bY)
		    d = Math.min(d, distanceToSegment(cirX, cirY, rX, tY, rX, bY));
		    // top side (lX,tY) & (rX,tY)
		    d = Math.min(d, distanceToSegment(cirX, cirY, lX, tY, rX, tY));
		    // bottom side (lX,bY) & (rX,bY)
		    d = Math.min(d, distanceToSegment(cirX, cirY, lX, bY, rX, bY));
		    if (d < radius) {
		        return true;
		    }
		//square-triangle
		} else if(otherObject instanceof Base || otherObject instanceof Drone) {
			int[] xPoints, yPoints;
			square = (Robot) this;
			if (otherObject instanceof Base) {
				base = (Base) otherObject;
				xPoints = ((Base) base).getXPoints();
				yPoints = ((Base) base).getYPoints();
			}else {
				drone = (Drone) otherObject;
				xPoints = ((Drone) drone).getXPoints();
				yPoints = ((Drone) drone).getYPoints();
				}

			Vector<Point> squarePoints = new Vector<Point>();
			int size = square.getSize();
			int pointX, pointY;
			Point point;
			//get all points of the square and put them into a vector
			for (int i = 1; i < size; i++){
				//left points
				pointX = square.getLeftX();
				pointY = square.getTopY()+i;
				point = new Point(pointX, pointY);
				squarePoints.add(point);
				//top points
				pointX = square.getLeftX()+i;
				pointY = square.getTopY();
				point = new Point(pointX, pointY);
				squarePoints.add(point);
				//right points
				pointX = square.getRightX();
				pointY = square.getBottomY()-i;
				point = new Point(pointX, pointY);
				squarePoints.add(point);
				//bottom points
				pointX = square.getRightX()-i;
				pointY = square.getBottomY();
				point = new Point(pointX, pointY);
				squarePoints.add(point);
				
			}
			
			return (contains(squarePoints, xPoints, yPoints));
		}


		return false;
		
	}
	
	//method that checks for square-triangle collision
	//detects if any point of the square is within the triangle
	public boolean contains(Vector<Point> squarePoints, int[] triangleX, int[] triangleY) {
		int x1 = triangleX[0];
		int y1 = triangleY[0];
		int x2 = triangleX[1];
		int y2 = triangleY[1];
		int x3 = triangleX[2];
		int y3 = triangleY[2];
		boolean result = false;
		
		Iterator<Point> itr = squarePoints.iterator();
		while (itr.hasNext()) {
			Point temp = itr.next();
			int px = temp.getX(); // pointer location relative to parent’s origin
			int py = temp.getY(); 
	    
			//determinant
			double detT = (y2 - y3)*(x1 - x3) + (x3 - x2)*(y1 - y3);
			//barycentric coordinates
			double alpha = ((y2 - y3)*(px - x3) + (x3 - x2)*(py - y3)) / detT;
			double beta = ((y3 - y1)*(px - x3) + (x1 - x3)*(py - y3)) / detT;
			double gamma = 1 - alpha - beta;
	    
			result = (alpha > 0 && beta > 0 && gamma > 0);
			if (result == true) {
				break;
			}
		}
		return result;
	}
	
	//calculates the distance from center of circle to side of square
	public double distanceToSegment(int x, int y, int x1, int y1, int x2, int y2) {
	    double A = x - x1;
	    double B = y - y1;
	    double C = x2 - x1;
	    double D = y2 - y1;

	    double dot = A * C + B * D;
	    double len_sq = C * C + D * D;
	    double param = dot / len_sq;

	    double xx, yy;

	    if (param < 0) {
	        xx = x1;
	        yy = y1;
	    } else if (param > 1) {
	        xx = x2;
	        yy = y2;
	    } else {
	        xx = x1 + param * C;
	        yy = y1 + param * D;
	    }

	    double dx = x - xx;
	    double dy = y - yy;
	    return Math.sqrt(dx * dx + dy * dy);
	}
	
	
	
	//method to check if a line segment intersects with a square
	private boolean lineIntersectsSquare(int x1, int y1, int x2, int y2, int lX, int rX, int tY, int bY) {
		if (x1 >= lX && x1 <= rX && y1 >= tY && y1 <= bY) {
			return true;
		}
		if (x2 >= lX && x2 <= rX && y2 >= tY && y2 <= bY) {
			return true;
		}
		if (x1 < lX && x2 < lX) {
			return false;
		}
		if (x1 > rX && x2 > rX) {
			return false;
		}
		if (y1 < tY && y2 < tY) {
			return false;
		}
		if (y1 > bY && y2 > bY) {
			return false;
		}
		return true;
	}
}
	

