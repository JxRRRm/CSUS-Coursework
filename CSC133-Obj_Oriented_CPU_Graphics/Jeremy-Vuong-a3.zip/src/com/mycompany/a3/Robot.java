package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;

public class Robot extends Movable implements ISteerable {
	private int steeringDirection = 0;
	private int maximumSpeed;
	private int energyLevel = 5000; 
	private int energyConsumptionRate = 1;
	private int damageLevel = 0;
	private int lastBaseReached; 
	private final int maxDmg;
	private int leftX, rightX, topY, bottomY;
	//constructor
	public Robot(final int objSize, double locX, double locY, int objColor, int objHeading, 
					int objSpeed, int objMaximumSpeed, final int objMaxDmg, int objLastBaseReached) 
	{
		super(objSize, locX, locY, objColor, objHeading, objSpeed);
		this.maximumSpeed = objMaximumSpeed;
		this.maxDmg = objMaxDmg;
		this.lastBaseReached = objLastBaseReached;
		
	}
	
	
	//steerLeft();method set turn the steering wheel of the robot 5 degrees to the left
	public void steerLeft() {
		if (steeringDirection > -40)
			setSteeringDirection(steeringDirection -5);
	}
	
	//steerRight();method set turn the steering wheel of the robot 5 degrees to the right
	public void steerRight() {
		if (this.steeringDirection < 40)
		setSteeringDirection(steeringDirection + 5);
	}
	
	
	// getters 
	public int getLastBaseReached() {
		return lastBaseReached;
	}
	public int getMaximumSpeed() {
		return maximumSpeed;
	}
	public int getEnergyLevel() {
		return energyLevel;
	}
	public int getDamageLevel() {
		return damageLevel;
	}
	public int getMaxDmg() {
		return maxDmg;
	}
	public int getSteeringDirection() {
		return steeringDirection;
	}
	public int getEnergyConsumptionRate() {
		return energyConsumptionRate;
	}
	public int getLeftX() {
		return leftX;
	}
	public int getRightX() {
		return rightX;
	}
	public int getTopY() {
		return topY;
	}
	public int getBottomY() {
		return bottomY;
	}

	//setters
	public void setLastBaseReached(int newBaseReached) {
		this.lastBaseReached =  newBaseReached;
	}
	public void setEnergyLevel(int nrgLevel) {
		this.energyLevel = nrgLevel;
	}
	public void setDamageLevel(int dmgLevel) {
		this.damageLevel = dmgLevel;
	}
	public void setSteeringDirection(int newDirection) {
		if (newDirection < -40)
			this.steeringDirection = -40;
		else if (newDirection > 40)
			this.steeringDirection = 40;
		else 
			this.steeringDirection = newDirection;
	}
	public void setLeftX(int leftX) {
		this.leftX = leftX;
	}
	public void setRightX(int rightX) {
		this.rightX = rightX;
	}
	public void setTopY(int topY) {
		this.topY = topY;
	}
	public void setBottomY(int bottomY) {
		this.bottomY = bottomY;
	}
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " maxSpeed=" + maximumSpeed 
							+ " steeringDirection=" + getSteeringDirection()
							+ " energyLevel=" + getEnergyLevel()
							+ " damageLevel=" + getDamageLevel();
		return parentDesc + myDesc;
	}
	


	@Override
	public void handleCollision(GameObject otherObject) {
		//Robot
		if (otherObject instanceof Robot) {
			//player robot takes damage
			double maxDmg = this.getMaxDmg();
			double percent = (5 + this.getDamageLevel())/maxDmg;
			double newSpeed = (this.getSpeed() - (this.getSpeed()*percent));
			//take damage
			this.setDamageLevel(this.getDamageLevel()+5);
			//update Speed
			this.setSpeed((int) newSpeed);
			
			
			// make color of robot lighter
			int r = ColorUtil.red(this.getColor())-15;
			int g = ColorUtil.green(this.getColor());
			int b = ColorUtil.blue(this.getColor());
			if (r<=0) {r=0;}
			if (g<=0) {g=0;}
			if (b<=0) {b=0;}
			int newColor = ColorUtil.rgb(r, g, b);
			this.setColor(newColor);
			
			//npr takes damage
			maxDmg = ((Robot) otherObject).getMaxDmg();
			percent = (5 + ((Robot) otherObject).getDamageLevel())/maxDmg;
			newSpeed = ((Robot) otherObject).getSpeed() - (((Movable) otherObject).getSpeed()*percent);
			//take damage
			((Robot) otherObject).setDamageLevel(((Robot) otherObject).getDamageLevel()+5);
			//update Speed
			((Robot) otherObject).setSpeed((int) newSpeed);
			
			// make color of npr lighter
			r = ColorUtil.red(otherObject.getColor())-5;
			g = ColorUtil.green(otherObject.getColor());
			b = ColorUtil.blue(otherObject.getColor());
			if (r<=0) {r=0;}
			if (g<=0) {g=0;}
			if (b<=0) {b=0;}
			newColor = ColorUtil.rgb(r, g, b);
			otherObject.setColor(newColor);	
			
			if (this.getX() > otherObject.getX()) {
				this.setX(this.getX()+5);
				otherObject.setX(otherObject.getX()-5);
			}else {
				this.setX(this.getX()-5);
				otherObject.setX(otherObject.getX()+5);
			}
			if (this.getY() > otherObject.getY()) {
				this.setY(this.getY()+5);
				otherObject.setY(otherObject.getY()-5);
			}else {
				this.setY(this.getY()-5);
				otherObject.setY(otherObject.getY()+5);
			}
			
		//Drone
		} else if (otherObject instanceof Drone) {
			double maxDmg = this.getMaxDmg();
			double percent = (2 + this.getDamageLevel())/maxDmg;
			double newSpeed = this.getSpeed() - (this.getSpeed()*percent);
			
			//take damage
			this.setDamageLevel(this.getDamageLevel() + 2);
			//update speed
			this.setSpeed((int)newSpeed);

			// make color of robot lighter
			int r = ColorUtil.red(this.getColor())-5;
			int g = ColorUtil.green(this.getColor());
			int b = ColorUtil.blue(this.getColor());
			if (r<0) {r=0;}
			if (g<0) {g=0;}
			if (b<0) {b=0;}
			int newColor = ColorUtil.rgb(r, g, b);
			this.setColor(newColor);
			if (this.getX() > otherObject.getX()) {
				this.setX(this.getX()+3);
				otherObject.setX(otherObject.getX()-5);
			}else {
				this.setX(this.getX()-5);
				otherObject.setX(otherObject.getX()+5);
			}
			if (this.getY() > otherObject.getY()) {
				this.setY(this.getY()+5);
				otherObject.setY(otherObject.getY()-5);
			}else {
				this.setY(this.getY()-5);
				otherObject.setY(otherObject.getY()+5);
			}
		
			//Base	
		} else if (otherObject instanceof Base) {
			if (((Base) otherObject).getSequenceNumber() == this.getLastBaseReached()+1) {
				this.setLastBaseReached(((Base) otherObject).getSequenceNumber());
			}//end if
			
		//Energy Station	
		} else if (otherObject instanceof EnergyStation) {
			if (((EnergyStation) otherObject).getCapacity() != 0) {
				// absorb energy and drain station's capacity
				this.setEnergyLevel(this.getEnergyLevel() + ((EnergyStation) otherObject).getCapacity());
				((EnergyStation) otherObject).drainCapacity();
				//fade energy station color
				int r = ColorUtil.red(otherObject.getColor());
				int g = ColorUtil.green(otherObject.getColor()) - 155; 
				int b = ColorUtil.blue(otherObject.getColor()); 
				if (r <= 0) {r = 0;}
				if (g <= 0) {g = 0;}
				if (b <= 0) {b = 0;}
				int newColor = ColorUtil.rgb(r, g, b);
				otherObject.setColor(newColor);
			}//end if
		}//end else if
	}//end handleCollision
	
}
