package com.mycompany.a3;

import com.codename1.util.MathUtil;

public class BaseStrategy implements IStrategy{
	private NonPlayerRobot npr;
	private GameObjectCollection collection;

	
	public BaseStrategy(NonPlayerRobot npr, GameObjectCollection gameObjects) {
		this.npr = npr;
		collection = gameObjects;
		
	}//end BaseStrategy

	public void apply() {
		double nprX = npr.getX();
		double nprY = npr.getY();
		double baseX = 0;
		double baseY = 0;
		double a, b;
		double angleA;
		int angleB;
		
		IIterator myIter = collection.getIterator();
		//find next base for npr and get its location
				while (myIter.hasNext()) {
					GameObject myObject = myIter.getNext();
					if (myObject instanceof Base) {
						if (((Base) myObject).getSequenceNumber() == npr.getLastBaseReached()+1) {
							baseX = myObject.getX();
							baseY = myObject.getY();
							break;
						}//end if
					}//end if
				}//end while	
		
		a = baseX - nprX;
		b = baseY- nprY;
		// calculate ideal angle
		angleA = (90 - Math.toDegrees(MathUtil.atan2(a,b)));

		angleB = 90 - (int)(angleA);	//ideal heading
		System.out.println("Ideal Heading = " + angleB);
		//set steering direction ??
		//npr.setSteeringDirection(angleB);
		//set heading
		npr.setHeading((int)angleB);
		//update strategy identifier
		npr.setStrategyID("Base");
	}
		
		
		
}


