package com.mycompany.a3;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;
import com.codename1.ui.plaf.Border;

public class MapView extends Container implements Observer {
	private GameWorld gw;

	public MapView(GameWorld gw) {
		super();
		// TODO Auto-generated constructor stub
		this.gw = gw;
		this.getAllStyles().setBorder(Border.createLineBorder(2,ColorUtil.rgb(255, 0, 0)));
	}

	@Override
	public void update (Observable o, Object arg) {
		// code here to call the method in GameWorld (Observable) that output the
		// game object information to the console
		gw = (GameWorld) arg;
		IIterator myIter = gw.getGameObjectCollection().getIterator();
		
		System.out.println("MAP: ");
		// display base description(s)
		while(myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof Base) {
				System.out.println("Base: " + myObject.toString()); 
			}
			else if (myObject instanceof PlayerRobot) {
				System.out.println("Player Robot: " + myObject.toString()); 
			}
			else if (myObject instanceof Robot) {
				System.out.println("NonPlayerRobot: " + myObject.toString()); 
			}
			else if (myObject instanceof Drone) {
				System.out.println("Drone: " + myObject.toString()); 
			}
			else if (myObject instanceof EnergyStation) {
				System.out.println("EnergyStation: " + myObject.toString()); 
			}
		}
		System.out.println();
		this.repaint();
		
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Point pCmpRelPrnt = new Point(this.getX(), this.getY());
		
		IIterator itr = gw.getGameObjectCollection().getIterator();
		while(itr.hasNext()) {
			GameObject obj = itr.getNext();
			if (obj instanceof IDrawable) {
				((IDrawable) obj).draw(g, pCmpRelPrnt);
			}
		}
	}
	
	@Override
	public void pointerPressed(int x, int y) {
		// make the pointer location relative to MapView's parent's origin
		x = x - this.getParent().getAbsoluteX();
		y = y - this.getParent().getAbsoluteY();
		Point pPtrRelPrnt = new Point(x, y);
		Point pCmpRelPrnt = new Point(getX(), getY());
		
		if (gw.getPaused() == true) {	    
		    // check if there is a Fixed object at the pointer location
		    IIterator itr = gw.getGameObjectCollection().getIterator();
		    while(itr.hasNext()) {
		        GameObject obj = itr.getNext();
		        if (obj instanceof ISelectable) {
		        	if (gw.getPosFlag() == false) {
		        		if (((ISelectable) obj).contains(pPtrRelPrnt, pCmpRelPrnt)) {
		        			// select the Fixed object
		        			((ISelectable) obj).setSelected(true);
		        		}else {
		        			//unselect all other objects
		        			((ISelectable) obj).setSelected(false);
		        		}
		        	}else {
		        		if (((ISelectable) obj).isSelected() == true) {
		        			obj.setX(pPtrRelPrnt.getX()-getX());
		        			obj.setY(pPtrRelPrnt.getY()-getY());
		        			gw.togglePosFlag();
		        		}
		        	}
		        //repaint the MapView to show the selected object
	            this.repaint();
		   }//end while
		} 
			
		}
	}//end pointerPressed()
	
}
