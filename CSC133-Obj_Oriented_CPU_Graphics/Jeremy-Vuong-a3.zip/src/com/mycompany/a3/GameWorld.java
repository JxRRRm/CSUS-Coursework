package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import java.util.Observable;
import java.util.Random;


public class GameWorld extends Observable {
	//game state data
	private double clockTicks;
	private int livesRemaining = 3;
	private boolean sound; 
	private boolean isPaused;
	private boolean posFlag;
	//game world dimensions
	private int width = 1024;
	private int height = 768;
	//other game data
	private final int lastBase = 4;
	// collection
	private GameObjectCollection gameObjectCollection = new GameObjectCollection();
	private IIterator myIter = gameObjectCollection.getIterator();
	// random generated numbers
	private Random rand = new Random();					//rand
	private int randOne = randomInt();					//random number between 10 and 50; used for drone instantiation
	private int randTwo = randomInt();
	
	// objects
	private Base baseOne, baseTwo, baseThree, baseFour;				
	private PlayerRobot playerRobot;
	private NonPlayerRobot nprOne, nprTwo, nprThree;
	private Drone droneOne, droneTwo;
	private EnergyStation stationOne, stationTwo;
	
	//sounds
	private Sound eStationSound, collisionSound, loseLifeSound;
	private BGSound bgSound;
	
	public void init() {
		//code here to create the 
		  //initial game objects/setup 
		clockTicks = 0;
		sound = false;
		isPaused = false;
		posFlag = false;
		
		baseOne = new Base(90, 200.0, 600.0, ColorUtil.rgb(0, 0, 255), 1);
		baseTwo = new Base(90, 1200.0, 200.0, ColorUtil.rgb(0, 0, 255), 2);
		baseThree = new Base(90, 600.0, 900.0, ColorUtil.rgb(0, 0, 255), 3);
		baseFour = new Base(90, 1400.0, 700.0, ColorUtil.rgb(0, 0, 255), 4);
		
		playerRobot = PlayerRobot.getRobot();
		
		/*Each NPR is to have an initial location which
		is “near” the first base, but not exactly at the first base; instead, each NPR should be at least
		several robot lengths away from the first base (baseOne.getX() + (40 * rand.nextInt(10)-4)) //(baseOne.getY() + (40 * rand.nextInt(10)-4))
		*/
		nprOne = new NonPlayerRobot(100, baseTwo.getX() + (100 * (Math.round((-3+(8)*rand.nextDouble())*10.0)/10.0)), 
				baseTwo.getY() + (100 * (Math.round((-3+(8)*rand.nextDouble())*10.0)/10.0)), ColorUtil.rgb(255, 0, 0), 0, 15, 100, 500, 1, 1);
		
		nprTwo = new NonPlayerRobot(100, baseOne.getX() + (100 * (Math.round((-3+(8)*rand.nextDouble())*10.0)/10.0)), 
				baseOne.getY() + (100 * (Math.round((-3+(8)*rand.nextDouble())*10.0)/10.0)), ColorUtil.rgb(255, 0, 0), 0, 15, 100, 500, 1, 2);
		
		nprThree = new NonPlayerRobot(100, baseOne.getX() + (100 * (Math.round((-3+(8)*rand.nextDouble())*10.0)/10.0)), 
				baseOne.getY() + (100 * (Math.round((-3+(8)*rand.nextDouble())*10.0)/10.0)), ColorUtil.rgb(255, 0, 0), 0, 15, 100, 500, 1, 3);

		
		droneOne = new Drone(80 + rand.nextInt(21), randomDouble(width-50), randomDouble(height-50), 
								ColorUtil.rgb(255, 0, 255), rand.nextInt(360), 10 + rand.nextInt(10));
		droneTwo = new Drone(80 + rand.nextInt(21), randomDouble(width-50) + 0.0, randomDouble(height-50), 
								ColorUtil.rgb(255, 0, 255), rand.nextInt(360), 10 + rand.nextInt(10));

		stationOne = new EnergyStation(randOne, randomDouble(width-50), randomDouble(height-50), ColorUtil.rgb(0, 255, 0), randOne);
		stationTwo = new EnergyStation(randTwo, randomDouble(width-50), randomDouble(height-50), ColorUtil.rgb(0, 255, 0), randTwo);	
		
			
		//add objects into collection
		gameObjectCollection.add(playerRobot);
		gameObjectCollection.add(baseOne);
		gameObjectCollection.add(baseTwo);
		gameObjectCollection.add(baseThree);
		gameObjectCollection.add(baseFour);
		
		gameObjectCollection.add(nprOne);
		gameObjectCollection.add(nprTwo);
		gameObjectCollection.add(nprThree);
		
		gameObjectCollection.add(droneOne);
		gameObjectCollection.add(droneTwo);
		gameObjectCollection.add(stationOne);
		gameObjectCollection.add(stationTwo);
		
		nprOne.setStrategy(new AttackStrategy(nprOne, gameObjectCollection));
		nprOne.setStrategyID("Attack");
		nprTwo.setStrategy(new AttackStrategy(nprTwo, gameObjectCollection));
		nprTwo.setStrategyID("Base");
		nprThree.setStrategy(new BaseStrategy(nprThree, gameObjectCollection));
		nprThree.setStrategyID("Base");
		
		this.setChanged();
		this.notifyObservers(this);
	}
	// additional methods here to 
	 // manipulate world objects and 
	 // related game state data 
		
	
//randomDouble();method to return rounded random double for drone location====================================|
	private double randomDouble(double dbl) 
	{
		double randomDouble;
		randomDouble = 50 + (dbl-50) * rand.nextDouble();
		randomDouble = (Math.round(randomDouble*100.0)/100.0);
		return randomDouble;
	}//end randomDouble()
	
//randomInt();method to generate a random integer between 75 and 150===========================================|
	private int randomInt() 
	{
		int randomInt = 75 + rand.nextInt(36);
		return randomInt;
	}//end randomInt()
	
	
//	
	
//win();method to handle win condition========================================================================|
	public void win() {
		System.out.println("Game over, you win! Total time:  " + getClockTicks() + "\n");
		livesRemaining = 3;
		clockTicks = 0;
		exit();
		
	}
//died();method to handle robot sustaining too much damage or robot running out of energy=====================|
	public void died() 
	{
		myIter = gameObjectCollection.getIterator();
		livesRemaining = livesRemaining- 1;
		
		if (livesRemaining == 0) 
		{
			//reset game
			livesRemaining = 3;
			clockTicks = 0;
			setSound(false);
			this.setChanged();
			this.notifyObservers(this);
			System.out.println("Game over, you failed!”");
			exit();
		}
		else
		{
			//restart with new life
			while (myIter.hasNext()) {
				GameObject myObject = myIter.getNext();
				if (myObject instanceof PlayerRobot) {
					myObject.setX(baseOne.getX());
					myObject.setY(baseOne.getY());
					myObject.setColor(ColorUtil.rgb(255, 0, 0));
					((PlayerRobot) myObject).setDamageLevel(0);
					((PlayerRobot) myObject).setEnergyLevel(5000);
					((PlayerRobot) myObject).setHeading(0);
					((PlayerRobot) myObject).setSpeed(10);
					((PlayerRobot) myObject).setLastBaseReached(1);
					((PlayerRobot) myObject).setSteeringDirection(0);
					((PlayerRobot) myObject).setColor(ColorUtil.rgb(250, 0, 0));
					this.setChanged();
					this.notifyObservers(this);
					System.out.println("You died! Restarting with new life...");
					break;
				}//end if
			}
		}
	}//end died()
	
//consumeEnergy();method to consume energy=======================================================================
	public void consumeEnergy() 
	{
		myIter = gameObjectCollection.getIterator();
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				((PlayerRobot) myObject).setEnergyLevel(((PlayerRobot) myObject).getEnergyLevel()-((PlayerRobot) myObject).getEnergyConsumptionRate());
			}
		}
		

	}//end consumeEnergy()


//tick();method to increment clock ticks======================================================================|
	public void tick() 
	{
		// increment game clock
		clockTicks += 0.02;

		// update player robot and drone headings, invoke npr strategies and move objects
		myIter = gameObjectCollection.getIterator();
		while(myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				((PlayerRobot) myObject).setHeading(((PlayerRobot) myObject).getHeading() + ((PlayerRobot) myObject).getSteeringDirection());
			}
			if (myObject instanceof Drone) {
				((Drone) myObject).setHeading(((Drone) myObject).getHeading() + (rand.nextInt(10) - 5));
			}
			if (myObject instanceof Movable) {
				((Movable) myObject).move(0.02);
				if (myObject instanceof NonPlayerRobot) {
					((NonPlayerRobot) myObject).invokeStrategy();
				}//end if
			}//end if
		}//end while
		
		//consume energy
		consumeEnergy();
		
		//collision detection
		collisionDetection();
		
		//check win condition and if died
		myIter = gameObjectCollection.getIterator();
		while(myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			
			if (myObject instanceof PlayerRobot) {
				if (((PlayerRobot) myObject).getEnergyLevel() < 1 || 
						((PlayerRobot) myObject).getDamageLevel() > ((PlayerRobot) myObject).getMaxDmg()) {
					if (((PlayerRobot) myObject).getDamageLevel() > ((PlayerRobot) myObject).getMaxDmg() && sound == true){
						loseLifeSound.play();
					}
					died();
				}else if(((PlayerRobot) myObject).getLastBaseReached() == lastBase) {
					win();
				}
			}
			if (myObject instanceof NonPlayerRobot) {
				if(((NonPlayerRobot) myObject).getLastBaseReached() == lastBase) {
					System.out.println("Game over, a non-player robot wins!");
					exit();
				}//end if
			}
		}

		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("CLOCK HAS TICKED!\n");
	}//end tick()

//accelerate();method to accelerate===========================================================================
	public void accelerate() 
	{
		myIter = gameObjectCollection.getIterator();		//iterator
		//increase player robot's speed
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//update player robot's speed
				((PlayerRobot) myObject).setSpeed(((Movable) myObject).getSpeed()+15);
				//cannot accelerate over max speed
				if (((PlayerRobot) myObject).getSpeed() > ((PlayerRobot) myObject).getMaximumSpeed())
					((PlayerRobot) myObject).setSpeed(((PlayerRobot) myObject).getMaximumSpeed());
				break;
			}//end if
		}//end while

		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("ROBOT HAS ACCELERATED!\n");							
	}//end accelerate()
	
//brake();method to brake=====================================================================================
	public void brake() 
	{
		myIter = gameObjectCollection.getIterator();		//iterator
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//apply brakes
				((PlayerRobot) myObject).setSpeed(((PlayerRobot) myObject).getSpeed()-10);
				//cannot reduce speed lower than 0
				if (((PlayerRobot) myObject).getSpeed() < 0)
					((PlayerRobot) myObject).setSpeed(0);
				break;
			}//end if
		}//end while

		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("BRAKES ARE APPLIED\n");
	}//end brake()

//method to steer left=========================================================================================
	public void steerLeft() 
	{
		myIter = gameObjectCollection.getIterator();		//iterator
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//invoke player robot's steerLeft method
				((PlayerRobot) myObject).steerLeft();
				break;
			}//end if
		}//end while
		
		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("STEERING WHEEL HAS TURNED LEFT\n");
	}//end steerLeft()
	
//steerRight();method to steer right===========================================================================
	public void steerRight() 
	{
		myIter = gameObjectCollection.getIterator();		//iterator
		
		while (myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				//invoke player robot's steerLeft method
				((PlayerRobot) myObject).steerRight();
				break;
			}//end if
		}//end while

		this.setChanged();
		this.notifyObservers(this);
		//print console message
		System.out.println("STEERING WHEEL HAS TURNED RIGHT\n");
	}//end steerRight()========================================================================================

//exit();method to terminate the program============================================================================
		public void exit() 
		{
			System.out.println("EXITING GAME...");
			System.exit(0);
		}//end exit()===============================================================================================
		

//changeStrategies();method to change npr strategies
		public void changeStrategies(){
			myIter = gameObjectCollection.getIterator();
			
			while (myIter.hasNext()) {
				GameObject myObject = myIter.getNext();
				if (myObject instanceof NonPlayerRobot) {
					if(((NonPlayerRobot) myObject).getStrategyID() == "Attack") {
						((NonPlayerRobot) myObject).setStrategy(new BaseStrategy((NonPlayerRobot)myObject, gameObjectCollection));
						((NonPlayerRobot) myObject).setStrategyID("Base");
					}
					else {
						((NonPlayerRobot) myObject).setStrategy(new AttackStrategy((NonPlayerRobot)myObject, gameObjectCollection));
						((NonPlayerRobot) myObject).setStrategyID("Attack");
					}//end else
					//((NonPlayerRobot) myObject).setLastBaseReached(((Robot) myObject).getLastBaseReached()+1);
				}//end if
			}//end while
			
			this.setChanged();
			this.notifyObservers(this);
			System.out.println("NPR STRATEGY CHANGED!");
			
		}//end changeStrategies
		
		public void collisionDetection() {
		    myIter = gameObjectCollection.getIterator();
		    
		    while (myIter.hasNext()) {
		        GameObject temp = myIter.getNext();
		        //only use robots to detect collision
		        if (temp instanceof Robot) {
		        	IIterator myIter2 = gameObjectCollection.getIterator();
		        	while (myIter2.hasNext()) {
		        		GameObject target = myIter2.getNext();
		        		if (target != temp) { //check if we are observing two different objects 
		        			if (temp.collidesWith(target)) { //if they collide
		        				//if target is not in collision vector
		        				if(!temp.isInCollisionVector(target)) { //if target is not in temp's collision vector
		        					//System.out.println("collision detected");	        					
		        					if (getSound()) {
		        						if (target instanceof Robot) {
		        							collisionSound.play();
		        						}else if (target instanceof EnergyStation) {
		        							eStationSound.play();
		        						}
		        					}
		        					temp.handleCollision(target);            //handle collision
		        					//add to collision vectors
		        					temp.addToCollisionVector(target);		
		        					//if target was an energy station, destroy it and make a new one
		        					if (target instanceof EnergyStation) {
		        						int randomNumber = randomInt();
		        						EnergyStation newStation = new EnergyStation(randomNumber, randomDouble(width-50), randomDouble(height-50), 
		                                        			ColorUtil.rgb(0, 255, 0), randomNumber);
		        						gameObjectCollection.add(newStation);
		        					}//end if
		        				}//end if 
		        			} else { //they don't collide
		        				if (temp.isInCollisionVector(target) && !(target instanceof EnergyStation)) {
		        					temp.removeFromCollisionVector(target);
		        				}//end if
		        			}//end else
		        		}//end if
		        	}//end while
		        }//end if
		    }//end while
		}//end collisionDetection()
		
		
		//createSounds
		public void createSounds() {
			eStationSound = new Sound("Energy.wav");
			collisionSound = new Sound("RobotCollision.wav");
			loseLifeSound = new Sound("LostLife.wav");
			bgSound = new BGSound("BGsound.wav");

		}

//getters
		public boolean getSound() {
			return sound;
		}
		
		public double getClockTicks() {
			return Math.round(clockTicks*100.0)/100.0;
		}
		
		public int getLivesRemaining() {
			return livesRemaining;
		}


		public int getWidth() {
			return width;
		}

		public int getHeight() {
			return height;
		}
		
		public GameObjectCollection getGameObjectCollection() {
			return gameObjectCollection;
		}
		
		public boolean getPaused() {
			return isPaused;
		}
		
		
//setters	
		public void setSound(boolean bool) {
				sound = bool;
				
				this.setChanged();
				this.notifyObservers(this);		
		}
		public void setPaused(boolean bool) {
			isPaused = bool;
		}
		public void setWidth(int w) {
			// TODO Auto-generated method stub
			this.width = w;
		}
		public void setHeight (int h) {
			this.height = h;
		}	
		
		
//getters for scoreview
		public int getLastBaseReached() {
			myIter = gameObjectCollection.getIterator();

			while(myIter.hasNext()) {
				GameObject player = myIter.getNext();
				if (player instanceof PlayerRobot) {
					return ((PlayerRobot) player).getLastBaseReached();
				}
			}
			return 0;
		}
		
		public int getEnergyLevel() {
			myIter = gameObjectCollection.getIterator();

			while(myIter.hasNext()) {
				GameObject player = myIter.getNext();
				if (player instanceof PlayerRobot) {
					return ((PlayerRobot) player).getEnergyLevel();
				}
			}
			return 0;
		}
		
		public int getDamageLevel() {
			myIter = gameObjectCollection.getIterator();

			while(myIter.hasNext()) {
				GameObject player = myIter.getNext();
				if (player instanceof PlayerRobot) {
			 		return ((PlayerRobot) player).getDamageLevel();
				}
			}
			return 0;
		}


		public boolean getPosFlag() {
			// TODO Auto-generated method stub
			return posFlag;
		}


		public void togglePosFlag() {
			// TODO Auto-generated method stub
			if(posFlag == false)
				posFlag = true;
			else
				posFlag = false;
		}
		
		public void setPosFlag(boolean value) {
			posFlag = value;
		}
		
		public void playBgSound() {
			bgSound.play();
		}
		public void pauseBgSound() {
			bgSound.pause();
		}
}//GameWorld
