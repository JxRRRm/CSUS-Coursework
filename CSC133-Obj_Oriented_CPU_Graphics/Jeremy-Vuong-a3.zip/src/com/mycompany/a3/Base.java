package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Font;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public class Base extends Fixed implements IDrawable{
	private int sequenceNumber;
	private int[] xPoints, yPoints;
	//constructor
	public Base(final int objSize, double locX, double locY, final int objColor, int objSequenceNumber) 
	{
		super(objSize, locX, locY, objColor);
		this.sequenceNumber = objSequenceNumber;
		// TODO Auto-generated constructor stub
	}
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " seqNum=" + sequenceNumber;
		return parentDesc + myDesc;
	}
	
	public int getSequenceNumber() {
		return sequenceNumber;
	}
	public int[] getXPoints() {
		return xPoints;
	}
	public int[] getYPoints() {
		return yPoints;
	}
	

	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		int size = getSize();
	    int x = (int) (pCmpRelPrnt.getX() + this.getX()-size/2);
	    int y = (int) (pCmpRelPrnt.getY() + this.getY()-size/2);

	    
	    xPoints = new int[] { x, x + size, x + (size/2) };
	    yPoints = new int[] { y, y, y + size };
	    
	    if (super.isSelected()) {
	    	g.setColor(ColorUtil.rgb(255, 0, 0));
			g.drawPolygon(xPoints, yPoints, 3);
			//drawn base number
	    	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_LARGE);
	    	g.setFont(font);
	    	g.setColor(ColorUtil.BLACK);
	    	g.drawString(""+getSequenceNumber(), x+37, y+13);
			  
	    } else {
	    	// Draw base
	    	g.setColor(getColor());
	    	g.fillPolygon(xPoints, yPoints, 3);
	    	// Draw base number
	    	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_LARGE);
	    	g.setFont(font);
	    	g.setColor(ColorUtil.WHITE);
	    	g.drawString(""+getSequenceNumber(), x+37, y+13);
	    }
	}

	@Override
	public void handleCollision(GameObject otherObject) {
		// TODO Auto-generated method stub
		
	}
	
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
	    int px = pPtrRelPrnt.getX(); // pointer location relative to parent’s origin
	    int py = pPtrRelPrnt.getY(); 
	    
	    int x1 = xPoints[0];
	    int y1 = yPoints[0];
	    int x2 = xPoints[1];
	    int y2 = yPoints[1];
	    int x3 = xPoints[2];
	    int y3 = yPoints[2];
	    
	    //determinant
	    double detT = (y2 - y3)*(x1 - x3) + (x3 - x2)*(y1 - y3);
	    //barycentric coordinates
	    double alpha = ((y2 - y3)*(px - x3) + (x3 - x2)*(py - y3)) / detT;
	    double beta = ((y3 - y1)*(px - x3) + (x1 - x3)*(py - y3)) / detT;
	    double gamma = 1 - alpha - beta;
	    
	    return (alpha > 0 && beta > 0 && gamma > 0);
	}
	

}