package com.mycompany.a3;

import com.codename1.ui.Button;
import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class PauseCommand extends Command {
	private GameWorld gw;   
    private Game game;
    private Button button;
    public PauseCommand(GameWorld gw, Game game, Button button) {
        super("Pause");
        this.gw = gw;
        this.button = button;
        this.game = game;
    }
    
    @Override
    public void actionPerformed(ActionEvent ev) {
    	//pause
    	if (gw.getPaused() == false) {
    		gw.setPaused(true);
            button.setText("Play");
            game.toggleCommands(false);
            if (gw.getSound()) {
            	gw.pauseBgSound();
            }
    	} else { //play
    		gw.setPaused(false);
    		gw.setPosFlag(false);
            button.setText("Pause");
            game.toggleCommands(true);
            if (gw.getSound()) {
            	gw.playBgSound();
            }
        }//end else
    }//action performed
}
