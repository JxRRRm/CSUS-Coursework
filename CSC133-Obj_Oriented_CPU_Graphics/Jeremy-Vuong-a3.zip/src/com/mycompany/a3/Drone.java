package com.mycompany.a3;

import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public class Drone extends Movable implements IDrawable{
	private int[] xPoints, yPoints;
	//constructor
	public Drone(final int objSize, double locX, double locY, final int objColor, int objHeading, int objSpeed) {
		super(objSize, locX, locY, objColor, objHeading, objSpeed);
		// TODO Auto-generated constructor stub
	}
	
	public int[] getXPoints() {
		return xPoints;
	}
	public int[] getYPoints() {
		return yPoints;
	}
	


	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		// TODO Auto-generated method stub
		int size = getSize();
	    int x = (int) (pCmpRelPrnt.getX() + this.getX()-size/2);
	    int y = (int) (pCmpRelPrnt.getY() + this.getY()-size/2);
	    
	    xPoints = new int[] { x, x + size, x + (size/2) };
	    yPoints = new int[] { y, y, y + size };
	      
	    g.setColor(getColor());
	    g.drawPolygon(xPoints, yPoints, 3);
	}
	

}
