package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public abstract class Fixed extends GameObject implements ISelectable{
	private boolean selected;
	//constructor
	public Fixed(final int objSize, double locX, double locY, int objColor) {
		super(objSize, locX, locY, objColor);
		// TODO Auto-generated constructor stub
	}

    @Override
    public void setSelected(boolean b) {
        selected = b;
    }

    @Override
    public boolean isSelected() {
        return selected;
    }

    @Override
    public void draw(Graphics g, Point pCmpRelPrnt) {
        int size = getSize();
        int x = (int) (pCmpRelPrnt.getX() + this.getX());
        int y = (int) (pCmpRelPrnt.getY() + this.getY());

        if (isSelected()) {
            g.setColor(ColorUtil.BLACK);
            g.drawArc(x, y, size, size, 0, 360);
        }

        g.setColor(getColor());
        g.fillArc(x, y, size, size, 0, 360);
    }

}
