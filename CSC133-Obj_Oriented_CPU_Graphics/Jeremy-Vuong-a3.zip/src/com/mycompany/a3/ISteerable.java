package com.mycompany.a3;

public interface ISteerable {
	public void steerLeft();
	public void steerRight();
}
