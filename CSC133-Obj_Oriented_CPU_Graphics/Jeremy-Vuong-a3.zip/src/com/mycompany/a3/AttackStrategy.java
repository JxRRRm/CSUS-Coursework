package com.mycompany.a3;

import com.codename1.util.MathUtil;

public class AttackStrategy implements IStrategy{
	private NonPlayerRobot nonPlayerRobot;
	private PlayerRobot playerRobot;
	
	public AttackStrategy(NonPlayerRobot npr, GameObjectCollection myCollection) {
		nonPlayerRobot = npr;
		
		IIterator myIter = myCollection.getIterator();
		
		while (myIter.hasNext()){
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				playerRobot = (PlayerRobot) myObject;
				break;
			}
		}
	}

	public void apply() {
		double nprX = nonPlayerRobot.getX();
		double nprY = nonPlayerRobot.getY();
		double playerX = playerRobot.getX();
		double playerY = playerRobot.getY();
		double a, b;
		double angleA;
		int angleB;
		

		a = playerX - nprX;
		b = playerY - nprY;

		//calculate ideal angle
		angleA = 90 - Math.toDegrees(MathUtil.atan2(a,b));

		angleB = 90 - (int)(angleA);	//ideal heading
		//set steering direction ??
		
		//set heading
		nonPlayerRobot.setHeading(angleB);
		
		nonPlayerRobot.setStrategyID("Attack");
	}
	

}
