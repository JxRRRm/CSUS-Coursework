package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public class PlayerRobot extends Robot implements IDrawable{
	private static PlayerRobot myRobot;
	
	public PlayerRobot(int objSize, double locX, double locY, int objColor, int objHeading, int objSpeed,
			int objMaximumSpeed, int objMaxDmg, int objLastBaseReached) {
		super(objSize, locX, locY, objColor, objHeading, objSpeed, objMaximumSpeed, objMaxDmg, objLastBaseReached);
		// TODO Auto-generated constructor stub
	}

	public static PlayerRobot getRobot() {
		if (myRobot == null)
			myRobot = new PlayerRobot(100, 200.0, 600.0, ColorUtil.rgb(255, 0, 0), 0, 15, 200, 100, 1);
		return myRobot;
	}


	@Override
		public void draw(Graphics g, Point pCmpRelPrnt) {
			int size = this.getSize();
			//top left of shape wrt container
		    int x = (int) (pCmpRelPrnt.getX() + this.getX() - size/2);
		    int y = (int) (pCmpRelPrnt.getY() + this.getY() - size/2);
		    
		    setLeftX(x);
		    setRightX(x+size);
		    setTopY(y);
		    setBottomY(y + size);
		    
		    // Draw robot 
		    g.setColor(getColor());
		    g.fillRect(x, y, getSize(), getSize());
		}

}
