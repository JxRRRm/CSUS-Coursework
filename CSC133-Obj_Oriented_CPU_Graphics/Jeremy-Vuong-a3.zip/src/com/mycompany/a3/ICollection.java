package com.mycompany.a3;

public interface ICollection {
	
	public void add(GameObject newObject);
	public IIterator getIterator();
}
