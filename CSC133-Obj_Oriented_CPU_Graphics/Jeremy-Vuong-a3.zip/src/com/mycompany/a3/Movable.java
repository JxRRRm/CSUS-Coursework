package com.mycompany.a3;

public class Movable extends GameObject {
	private int heading;
	private int speed;
	
	//constructor
	public Movable(final int objSize, double locX, double locY, int objColor, int objHeading, int objSpeed) 
	{
		super(objSize, locX, locY, objColor);
		this.heading = objHeading;
		this.speed = objSpeed;
	}
	
	
	
	//getters
	public int getSpeed() 
	{
		return speed;
	}
	//
	public int getHeading() 
	{
		return heading;
	}
	
	//setters
	public void setSpeed(int newSpeed) 
	{
		this.speed = newSpeed;
	}
	
	public void setHeading(int newHeading) 
	{
		if (newHeading > 360) 
		{
			newHeading = newHeading - 360;
		}
		else if (newHeading < 0)
		{
			newHeading = 360 + newHeading;
		}
		
		this.heading = newHeading;
	}
	
	//move();method to move object 
	public void move(double time) {
		double theta = 90 - getHeading(); 
		
		
		double deltaX = Math.cos(Math.toRadians(theta)) * (getSpeed() * time); 
		double deltaY = Math.sin(Math.toRadians(theta)) * (getSpeed() * time);
		
		double newX = getX() + deltaX;
		double newY = getY() + deltaY;
		newX = Math.round(newX*10.0)/10.0;
		newY = Math.round(newY*10.0)/10.0;
		int offset = (this.getSize()/2);

		//X
		if ((newX < 0+offset) || (newX > 1614-offset)) {
			if (newX < 0+offset) {
				this.setX(0+offset);
			}
			else {
				this.setX(1614-offset);
			}
		}
		else {
			this.setX(newX);
		}
		//Y
		if ((newY < 0+offset) || (newY > 1220-offset)) {
			if (newY < 0+offset) {
				this.setY(0+offset);
			}
			else {
				this.setY(1220-offset);
			}
		}
		else {
			this.setY(newY);
		}
		
		//if the object hits the wall, bounce directly in the opposite direction
		if ((newX < 0+offset) || (newX > 1614-offset) 
				|| (newY < 0+offset) || (newY > 1220-offset))	
			this.setHeading(this.getHeading()+180);
		
	}
	
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " heading=" + getHeading() 
				+ " speed=" + getSpeed();
		return parentDesc + myDesc;
	}


	@Override
	public void handleCollision(GameObject otherObject) {
		// TODO Auto-generated method stub
		
	}

}
