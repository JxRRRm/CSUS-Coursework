package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Font;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public class NonPlayerRobot extends Robot implements IDrawable{
	private IStrategy curStrategy;
	private String strategyID;		
	private int nprID;

	public NonPlayerRobot(int objSize, double locX, double locY, int objColor, int objHeading, int objSpeed,
			int objMaximumSpeed, int objMaxDmg, int objLastBaseReached, int nprID) {
		super(objSize, locX, locY, objColor, objHeading, objSpeed, objMaximumSpeed, objMaxDmg, objLastBaseReached);
		// TODO Auto-generated constructor stub
		this.nprID = nprID;
	}


	public void setStrategy(IStrategy newStrategy) {
		// TODO Auto-generated method stub
		this.curStrategy = newStrategy;
	}


	public void invokeStrategy() {
		// TODO Auto-generated method stub
		this.curStrategy.apply();
	}
	
	public String getStrategyID() {
		return strategyID;
	}
	
	public void setStrategyID(String iD) {
		strategyID = iD;
	}
	
	public int getID() {
		return nprID;
	}
	
	//toString();method to return object description
		public String toString() {
			String parentDesc = super.toString();
			String myDesc = " Strategy=" + getStrategyID();
			return parentDesc + myDesc;
		}

		@Override
		public void draw(Graphics g, Point pCmpRelPrnt) {
			// TODO Auto-generated method stub
			int size = this.getSize();
		    int x = (int) (pCmpRelPrnt.getX() + this.getX() - size/2);
		    int y = (int) (pCmpRelPrnt.getY() + this.getY() - size/2);
		    
		    setLeftX(x);
		    setRightX(x+size);
		    setTopY(y);
		    setBottomY(y+size);

		    // Draw robot square
		    g.setColor(getColor());
		    g.drawRect(x, y, getSize(), getSize());
		    
		    // Draw npr number
	        Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_LARGE);
	        g.setFont(font);
		    g.setColor(ColorUtil.BLACK);
		    g.drawString(""+getID(), x+(size/2), y+(size/2));
		    
		}
		


}
