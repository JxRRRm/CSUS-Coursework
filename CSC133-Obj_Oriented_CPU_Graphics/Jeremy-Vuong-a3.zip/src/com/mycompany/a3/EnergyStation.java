package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Font;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public class EnergyStation extends Fixed implements IDrawable{
	private int capacity;
	private int radius, centerX, centerY;
	//constructor
	public EnergyStation(final int objSize, double locX, double locY, int objColor, int objCapacity) {
		super(objSize, locX, locY, objColor);
		this.capacity = objCapacity;

	}
	//getters
	public int getCapacity() {
		return capacity;
	}
	public int getRadius() {
		return radius;
	}
	public int getCenterX() {
		return centerX;
	}
	public int getCenterY() {
		return centerY;
	}
	
	//drainCapacity();method to drain energy station's capacity
	public void drainCapacity() {
		this.capacity = 0;
	}
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " capacity=" + capacity;
		return parentDesc + myDesc;
	}
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		int size = this.getSize();	//make size bigger for visual
		int r = size/2;
		//top left of shape wrt container
		int x = (int) (pCmpRelPrnt.getX() + this.getX() - r);
        int y = (int) (pCmpRelPrnt.getY() + this.getY() - r);
        
        
        centerX = (int) (pCmpRelPrnt.getX() + this.getX());
        centerY = (int) (pCmpRelPrnt.getY() + this.getY());
        radius = r;
        g.setColor(getColor());
        if (this.isSelected()) {
        	//draw unfilled arc
        	g.setColor(ColorUtil.rgb(255, 0, 0));
			g.drawArc(x, y, size, size, 0, 360);
			//draw capacity
			// Draw capacity
        	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_LARGE);
        	g.setFont(font);
        	g.setColor(ColorUtil.BLACK);
        	g.drawString(""+getCapacity(), x+25, y+30);
        }else {
        	// Draw filled arc
        	g.setColor(getColor());
        	g.fillArc(x, y, size, size, 0, 360);
        	// Draw capacity
        	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_LARGE);
        	g.setFont(font);
        	g.setColor(ColorUtil.BLACK);
        	g.drawString(""+getCapacity(), x+25, y+30);
        }
	    
	}

	@Override
	public void handleCollision(GameObject otherObject) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
	    int px = pPtrRelPrnt.getX(); // pointer location relative to parent’s origin
	    int py = pPtrRelPrnt.getY(); 
	    int xLoc = (int) (pCmpRelPrnt.getX() + getX() - getRadius()); // shape location relative to parent’s origin
	    int yLoc = (int) (pCmpRelPrnt.getY() + getY() - getRadius()); 
	    
	    // calculate the center point of the circle
	    int centerX = xLoc + getRadius();
	    int centerY = yLoc + getRadius();
	    
	    int dx = px - centerX;
	    int dy = py - centerY;
	    // calculate the distance between the pointer and the center of the circle
	    double distance = Math.sqrt((dx*dx) + (dy*dy));
	    
	    // check if the distance is within the radius of the circle
	    if (distance <= getRadius()) {
	        return true;
	    } else {
	        return false;
	    }
	}

}