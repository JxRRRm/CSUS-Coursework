package com.mycompany.a4;

import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

public class Robot extends Movable implements ISteerable {
	private int steeringDirection = 0;
	private int maximumSpeed;
	private int energyLevel = 5000; 
	private int energyConsumptionRate = 1;
	private int damageLevel = 0;
	private int lastBaseReached; 
	private final int maxDmg;
	private float leftX, rightX, topY, bottomY;
	private Point bottomLeftPoint;
	//constructor
	public Robot(final int objSize, int objColor, int objHeading, 
					int objSpeed, int objMaximumSpeed, final int objMaxDmg, int objLastBaseReached) 
	{
		super(objSize, objColor, objHeading, objSpeed);
		this.maximumSpeed = objMaximumSpeed;
		this.maxDmg = objMaxDmg;
		this.lastBaseReached = objLastBaseReached;
		bottomLeftPoint = new Point(-getSize()/2, -getSize()/2);
		
		leftX = bottomLeftPoint.getX();
		rightX = leftX +getSize();
		bottomY = bottomLeftPoint.getY();
		topY = bottomY + getSize();
		
	}
	
	
	//steerLeft();method set turn the steering wheel of the robot 5 degrees to the left
	public void steerLeft() {
		//float initialRotate = getRotateAngle();
		//float rotateAngle = initialRotate +(float) Math.toRadians(5);
		//float x = getTranslate().getTranslateX();
		//float y = getTranslate().getTranslateY();
		if (this.steeringDirection < 40) 
			setSteeringDirection(steeringDirection +5);

			//rotate(rotateAngle -initialRotate , x, y);
		
		
	}
	
	//steerRight();method set turn the steering wheel of the robot 5 degrees to the right
	public void steerRight() {
		//float initialRotate = getRotateAngle();
		//float rotateAngle = initialRotate +(float) Math.toRadians(5);
		//float x = getTranslate().getTranslateX();
		//float y = getTranslate().getTranslateY();
		
		if (steeringDirection > -40) 
			setSteeringDirection(steeringDirection -5);
			//rotate(rotateAngle - initialRotate, x, y);
		
	}
	
	
	// getters 
	public int getLastBaseReached() {
		return lastBaseReached;
	}
	public int getMaximumSpeed() {
		return maximumSpeed;
	}
	public int getEnergyLevel() {
		return energyLevel;
	}
	public int getDamageLevel() {
		return damageLevel;
	}
	public int getMaxDmg() {
		return maxDmg;
	}
	public int getSteeringDirection() {
		return steeringDirection;
	}
	public int getEnergyConsumptionRate() {
		return energyConsumptionRate;
	}
	public float getLeftX() {
		return leftX;
	}
	public float getRightX() {
		return rightX;
	}
	public float getTopY() {
		return topY;
	}
	public float getBottomY() {
		return bottomY;
	}
	

	//setters
	public void setLastBaseReached(int newBaseReached) {
		this.lastBaseReached =  newBaseReached;
	}
	public void setEnergyLevel(int nrgLevel) {
		this.energyLevel = nrgLevel;
	}
	public void setDamageLevel(int dmgLevel) {
		this.damageLevel = dmgLevel;
	}
	public void setSteeringDirection(int newDirection) {
		if (newDirection < -40)
			this.steeringDirection = -40;
		else if (newDirection > 40)
			this.steeringDirection = 40;
		else 
			this.steeringDirection = newDirection;
	}
	

	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " maxSpeed=" + maximumSpeed 
							+ " steeringDirection=" + getSteeringDirection()
							+ " energyLevel=" + getEnergyLevel()
							+ " damageLevel=" + getDamageLevel();
		return parentDesc + myDesc;
	}
	


	@Override
	public void handleCollision(GameObject otherObject) {
		float thisX = getTranslate().getTranslateX();
		float thisY = getTranslate().getTranslateY();
		float otherX = otherObject.getTranslate().getTranslateX();
		float otherY = otherObject.getTranslate().getTranslateY();
		float thisNewX, thisNewY, otherNewX, otherNewY;
		//Robot
		if (otherObject instanceof Robot) {
			//player robot takes damage
			double maxDmg = this.getMaxDmg();
			double percent = (5 + this.getDamageLevel())/maxDmg;
			double newSpeed = (this.getSpeed() - (this.getSpeed()*percent));
			//take damage
			this.setDamageLevel(this.getDamageLevel()+5);
			//update Speed
			this.setSpeed((int) newSpeed);
			
			
			// make color of robot lighter
			int r = ColorUtil.red(this.getColor())-15;
			int g = ColorUtil.green(this.getColor());
			int b = ColorUtil.blue(this.getColor());
			if (r<=0) {r=0;}
			if (g<=0) {g=0;}
			if (b<=0) {b=0;}
			int newColor = ColorUtil.rgb(r, g, b);
			this.setColor(newColor);
			
			//npr takes damage
			maxDmg = ((Robot) otherObject).getMaxDmg();
			percent = (5 + ((Robot) otherObject).getDamageLevel())/maxDmg;
			newSpeed = ((Robot) otherObject).getSpeed() - (((Robot) otherObject).getSpeed()*percent);
			//take damage
			((Robot) otherObject).setDamageLevel(((Robot) otherObject).getDamageLevel()+5);
			//update Speed
			((Robot) otherObject).setSpeed((int) newSpeed);
			
			// make color of npr lighter
			r = ColorUtil.red(otherObject.getColor())-5;
			g = ColorUtil.green(otherObject.getColor());
			b = ColorUtil.blue(otherObject.getColor());
			if (r<=0) {r=0;}
			if (g<=0) {g=0;}
			if (b<=0) {b=0;}
			newColor = ColorUtil.rgb(r, g, b);
			otherObject.setColor(newColor);	
			
			if (thisX > otherX) {
				//this.setX(thisX+5);
				//otherObject.setX(otherX-5);
				thisNewX = thisX+5;
				otherNewX = otherX-5;
				
			}else {
				//this.setX(thisX-5);
				//otherObject.setX(otherX+5);
				thisNewX = thisX-5;
				otherNewX = otherX+5;
			}
			if (thisY > otherY) {
				//this.setY(thisY+5);
				//otherObject.setY(otherY-5);
				thisNewY = thisY+5;
				otherNewY = otherY-5;
			}else {
				//this.setY(thisY-5);
				//otherObject.setY(otherY+5);
				thisNewY = thisY-5;
				otherNewY = otherY+5;
			}
			this.translate(thisNewX-thisX, thisNewY-thisY);
			otherObject.translate(otherNewX-otherX, otherNewY-otherY);
			
		//Drone
		} else if (otherObject instanceof Drone) {
			double maxDmg = this.getMaxDmg();
			double percent = (2 + this.getDamageLevel())/maxDmg;
			double newSpeed = this.getSpeed() - (this.getSpeed()*percent);
			
			//take damage
			this.setDamageLevel(this.getDamageLevel() + 2);
			//update speed
			this.setSpeed((int)newSpeed);

			// make color of robot lighter
			int r = ColorUtil.red(this.getColor())-5;
			int g = ColorUtil.green(this.getColor());
			int b = ColorUtil.blue(this.getColor());
			if (r<0) {r=0;}
			if (g<0) {g=0;}
			if (b<0) {b=0;}
			int newColor = ColorUtil.rgb(r, g, b);
			this.setColor(newColor);
			if (thisX > otherX) {
				//this.setX(thisX+5);
				//otherObject.setX(otherX-5);
				thisNewX = thisX+2;
				otherNewX = otherY-2;
			}else {
				//this.setX(thisX-5);
				//otherObject.setX(otherX+5);
				thisNewX = thisX-2;
				otherNewX = otherX+2;
			}
			if (thisY > otherY) {
				//this.setY(thisY+5);
				//otherObject.setY(otherY-5);
				thisNewY = thisY+2;
				otherNewY = otherY-2;
			}else {
				//this.setY(thisY-5);
				//otherObject.setY(otherY+5);
				thisNewY = thisY-2;
				otherNewY = otherY+2;
			}
			translate(thisNewX-thisX, thisNewY-thisY);
			otherObject.translate(otherNewX-otherX, otherNewY-otherY);
		
			//Base	
		} else if (otherObject instanceof Base) {
			if (((Base) otherObject).getSequenceNumber() == this.getLastBaseReached()+1) {
				this.setLastBaseReached(((Base) otherObject).getSequenceNumber());
				if (this instanceof NonPlayerRobot) {
				}
			}//end if
			
		//Energy Station	
		} else if (otherObject instanceof EnergyStation) {
			if (((EnergyStation) otherObject).getCapacity() != 0) {
				// absorb energy and drain station's capacity
				this.setEnergyLevel(this.getEnergyLevel() + ((EnergyStation) otherObject).getCapacity());
				((EnergyStation) otherObject).drainCapacity();
				//fade energy station color
				int r = ColorUtil.red(otherObject.getColor());
				int g = ColorUtil.green(otherObject.getColor()) - 155; 
				int b = ColorUtil.blue(otherObject.getColor()); 
				if (r <= 0) {r = 0;}
				if (g <= 0) {g = 0;}
				if (b <= 0) {b = 0;}
				int newColor = ColorUtil.rgb(r, g, b);
				otherObject.setColor(newColor);
			}//end if
		}//end else if
	}//end handleCollision


	public Point getBottomLeftPoint() {
		return bottomLeftPoint;
	}
	
}
