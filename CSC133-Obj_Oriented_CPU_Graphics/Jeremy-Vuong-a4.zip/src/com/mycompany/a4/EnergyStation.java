package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Font;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;

public class EnergyStation extends Fixed implements IDrawable{
	private int capacity;
	private int radius;
	private Point bottomLeftPoint;
	//constructor
	public EnergyStation(final int objSize, int objColor, int objCapacity) {
		super(objSize, objColor);
		this.capacity = objCapacity;
		radius = getSize()/2;
		bottomLeftPoint = new Point(-getSize()/2, -getSize()/2);

	}
	//getters
	public int getCapacity() {
		return capacity;
	}
	public int getRadius() {
		return radius;
	}
	
	//drainCapacity();method to drain energy station's capacity
	public void drainCapacity() {
		this.capacity = 0;
	}
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " capacity=" + capacity;
		return parentDesc + myDesc;
	}
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn, Transform gXform) {
		int size = getSize();	//make size bigger for visual
		//top left of shape wrt container
		int bLx = (int) (bottomLeftPoint.getX() + pCmpRelPrnt.getX());
        int bLy = (int) (bottomLeftPoint.getY() + pCmpRelPrnt.getY());
        
      ///*
	    // Save the current Graphics transform
	    Transform gXformCopy = gXform.copy();
	    Transform LT = Transform.makeIdentity();
	    // Perform local origin transformation - part two
	    LT.translate(pCmpRelScrn.getX(), pCmpRelScrn.getY());
	    // Append LTs of the object onto the Graphics transform
	    LT.concatenate(getTranslate());
	    LT.concatenate(getScale());
	    
	    // Perform local origin transformation - part one
	    LT.translate(-pCmpRelScrn.getX(), -pCmpRelScrn.getY());
	    gXformCopy.concatenate(LT);

	    // Apply the transformed Graphics transform to the Graphics object
	    g.setTransform(gXformCopy);
	    //*/
        
        if (this.isSelected()) {
        	//draw unfilled arc
        	g.setColor(ColorUtil.rgb(255, 0, 0));
			g.drawArc(bLx, bLy, size, size, 0, 360);
			//draw capacity
        	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
        	g.setFont(font);
        	g.setColor(ColorUtil.BLACK);
        	g.scale(1, -1);
        	g.drawString(""+getCapacity(), pCmpRelPrnt.getX()-18, pCmpRelPrnt.getY()-395);
        }else {
        	// Draw filled arc
        	g.setColor(getColor());
        	g.fillArc(bLx, bLy, size, size, 0, 360);
        	// Draw capacity
        	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
        	g.setFont(font);
        	g.setColor(ColorUtil.BLACK);
        	g.scale(1, -1);
        	g.drawString(""+getCapacity(), pCmpRelPrnt.getX()-18, pCmpRelPrnt.getY()-395);
        }
        
        g.setTransform(gXform);  
	}

	@Override
	public void handleCollision(GameObject otherObject) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
		float px = pPtrRelPrnt.getX(); 
	    float py = pPtrRelPrnt.getY();
	    float[] initPts = {px, py};
	    float[] transfPts = new float[2];
	    float inverseTx = -getTranslate().getTranslateX();
	    float inverseTy = -getTranslate().getTranslateY();
	    float inverseSx = 1/getScale().getScaleX();
	    float inverseSy = 1/getScale().getScaleY();   
	    
	    Transform inverseLT = Transform.makeIdentity();
	    inverseLT.scale(inverseSx, inverseSy);
	    inverseLT.translate(inverseTx, inverseTy);
	    inverseLT.transformPoint(initPts, transfPts);
	    px = transfPts[0];
	    py = transfPts[1];
	    //System.out.println("px = " + px);
	    //System.out.println("py = " + py);
	    
	    float centerX = bottomLeftPoint.getX() +getSize()/2;
	    float centerY = bottomLeftPoint.getY() +getSize()/2;
	    //System.out.println("Centerx = " + centerX);
	    //System.out.println("Centery = " + centerY);
	    
	    float dx = px - centerX;
	    float dy = py - centerY;
	    //System.out.println("px-cx = " + dx);
	    //System.out.println("py-cy = " + dy);
	    // calculate the distance between the pointer and the center of the circle
	    double distance = Math.sqrt((dx*dx) + (dy*dy));
	    //System.out.println("distance = " + distance + "____" + getRadius());
	    //System.out.println();
	    // check if the distance is within the radius of the circle
	    if (distance <= getRadius()) {
	        return true;
	    } else {
	        return false;
	    }
	}

}