package com.mycompany.a4;

import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;

public interface IDrawable {
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn, Transform gXform);
}
