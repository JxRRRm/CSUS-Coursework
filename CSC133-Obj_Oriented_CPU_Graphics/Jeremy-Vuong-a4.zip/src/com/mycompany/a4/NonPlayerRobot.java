package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Font;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;

public class NonPlayerRobot extends Robot implements IDrawable{
	private IStrategy curStrategy;
	private String strategyID;		
	private int nprID;

	public NonPlayerRobot(int objSize, int objColor, int objHeading, int objSpeed,
			int objMaximumSpeed, int objMaxDmg, int objLastBaseReached, int nprID) {
		super(objSize, objColor, objHeading, objSpeed, objMaximumSpeed, objMaxDmg, objLastBaseReached);
		// TODO Auto-generated constructor stub
		this.nprID = nprID;
	}


	public void setStrategy(IStrategy newStrategy) {
		// TODO Auto-generated method stub
		this.curStrategy = newStrategy;
	}


	public void invokeStrategy() {
		// TODO Auto-generated method stub
		this.curStrategy.apply();
	}
	
	public String getStrategyID() {
		return strategyID;
	}
	
	public void setStrategyID(String iD) {
		strategyID = iD;
	}
	
	public int getID() {
		return nprID;
	}
	
	//toString();method to return object description
		public String toString() {
			String parentDesc = super.toString();
			String myDesc = " Strategy=" + getStrategyID();
			return parentDesc + myDesc;
		}

		@Override
		public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn, Transform gXform) {
			int bLx = (int) getBottomLeftPoint().getX() + pCmpRelPrnt.getX();
			int bLy = (int) getBottomLeftPoint().getY() + pCmpRelPrnt.getY();
			int size = getSize();

		    ///*
		    // Save the current Graphics transform
		    Transform gXformCopy = gXform.copy();
		    Transform LT = Transform.makeIdentity();
		    // Perform local origin transformation - part two
		    LT.translate(pCmpRelScrn.getX(), pCmpRelScrn.getY());
		    // Append LTs of the object onto the Graphics transform
		    LT.concatenate(getTranslate());
		    LT.concatenate(getRotate());
		    LT.concatenate(getScale());
		    
		    // Perform local origin transformation - part one
		    LT.translate(-pCmpRelScrn.getX(), -pCmpRelScrn.getY());
		    gXformCopy.concatenate(LT);

		    // Apply the transformed Graphics transform to the Graphics object
		    g.setTransform(gXformCopy);
		    //*/
		    // Draw robot square
		    g.setColor(getColor());
		    g.drawRect(bLx, bLy, size, size);
		    
		    // Draw npr number
	        Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
	        g.setFont(font);
		    g.setColor(ColorUtil.BLACK);
		    g.scale(1, -1);
		    g.drawString(""+getID(), pCmpRelPrnt.getX()-5, pCmpRelPrnt.getY()-395);
		    
		    g.setTransform(gXform);
		    
		}
		


}
