package com.mycompany.a4;

public interface IStrategy {
	public void apply();
}
