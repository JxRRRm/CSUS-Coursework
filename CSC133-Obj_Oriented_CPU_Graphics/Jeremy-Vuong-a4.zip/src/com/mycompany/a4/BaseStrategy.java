package com.mycompany.a4;

import com.codename1.util.MathUtil;

public class BaseStrategy implements IStrategy{
	private NonPlayerRobot npr;
	private GameObjectCollection collection;

	
	public BaseStrategy(NonPlayerRobot npr, GameObjectCollection gameObjects) {
		this.npr = npr;
		collection = gameObjects;
		
	}//end BaseStrategy

	public void apply() {
		float nprX = npr.getTranslate().getTranslateX();
		float nprY = npr.getTranslate().getTranslateY();
		double baseX = 0;
		double baseY = 0;
		double a, b;
		double angleA;

		
		IIterator myIter = collection.getIterator();
		//find next base for npr and get its location
				while (myIter.hasNext()) {
					GameObject myObject = myIter.getNext();
					if (myObject instanceof Base) {
						if (((Base) myObject).getSequenceNumber() == npr.getLastBaseReached()+1) {
							baseX = myObject.getTranslate().getTranslateX();
							baseY = myObject.getTranslate().getTranslateY();
						}//end if
					}//end if
				}//end while	
		
		a = baseX - nprX;
		b = baseY- nprY;
		// calculate ideal angle
		angleA = (90 - Math.toDegrees(MathUtil.atan2(b, a)));
		System.out.println("angle = " + angleA);


		//set steering direction ??
		//npr.setSteeringDirection(angleB);
		int oldHeading = npr.getHeading();
		//set heading
		npr.setHeading((int)-angleA);
		npr.rotate(npr.getHeading() -oldHeading, 0, 0);
		//update strategy identifier
		npr.setStrategyID("Base");
	}
		
		
		
}


