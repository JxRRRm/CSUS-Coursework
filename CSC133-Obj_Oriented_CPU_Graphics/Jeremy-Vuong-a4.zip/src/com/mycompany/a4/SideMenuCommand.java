package com.mycompany.a4;

import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.events.ActionEvent;

public class SideMenuCommand extends Command {
	private GameWorld gw;
	public SideMenuCommand(String command, GameWorld gw) {
		super(command);
		this.gw = gw;
	}

	
	public void actionPerformed(ActionEvent ev) {
		switch(getCommandName()){
		   case "About":
		   		Dialog.show("About ", "Name: Jeremy Vuong\nCourse: CSC 133-05\nAssignment#: 3\n ", null, "Close");
		   		break;
		   case "Exit":
			   Boolean bOk = Dialog.show("Quit", "Are you sure you want to quit?", "OK", "Cancel");
			   if (bOk) //check if ok or cancel
			   Display.getInstance().exitApplication(); //exit
			   break;
		   case "Help":
			   Dialog.show("Game Controls", "KeyBinding                                     Action\n"
			   								+ "a                                               accelerate\n"
			   								+ "b                                                       brake\n"
			   								+ "l                                                   left turn\n"
			   								+ "r                                                 right turn\n"
			   								+ "e              collide with energy station\n"
			   								+ "g                              collide with drone\n"
			   								+ "t                                                           tick\n"
			   								+ "m                                                         map", null, "Close");
		   		break;
		   case "Sound":
			   if (((CheckBox) ev.getComponent()).isSelected()) {
				   gw.setSound(true);
				   gw.playBgSound();
			   }
			   else {
				   gw.setSound(false);
				   gw.pauseBgSound();
			   }
			   break;
		}
	}
	

}
