package com.mycompany.a4;

import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Border;

public class ScoreView extends Container implements Observer {
	private GameWorld gw;
	private Vector<Label> nameLabelVector = new Vector<Label>();
	private Vector<Label> dataLabelVector = new Vector<Label>();
	private Label timeLabel, livesLeftLabel, lastBaseLabel, energyLabel, dmgLabel, soundLabel;
	private Label timeData, livesLeftData, lastBaseData, energyData, dmgData, soundData;
	
	public ScoreView() {
		super();
			this.setLayout(BoxLayout.x());
			this.getAllStyles().setBgTransparency(50);
			this.getAllStyles().setBgColor(ColorUtil.LTGRAY);
			this.getAllStyles().setBorder(Border.createLineBorder(1,ColorUtil.GRAY));
			this.getAllStyles().setPadding(Component.LEFT, 80);
			this.getAllStyles().setPadding(Component.TOP, 5);
			this.getAllStyles().setPadding(Component.BOTTOM, 5);
			
			setLabels();
			styleLabels();

	}
	
	public void setLabels() {
		timeLabel = new Label("Time:");
		timeData = new Label("0.00");

		livesLeftLabel = new Label("Lives Left:");
		livesLeftData = new Label("3");
		
		lastBaseLabel = new Label("Player Last Base Reached:");
		lastBaseData = new Label("1");
		
		energyLabel = new Label("Player Energy Level:");
		energyData = new Label("5000");
		
		dmgLabel = new Label("Player Damage Level:");
		dmgData = new Label("100");
		
		soundLabel = new Label("Sound:");
		soundData = new Label("OFF");
		// add name labels to vector
		nameLabelVector.add(timeLabel);
		nameLabelVector.add(livesLeftLabel);
		nameLabelVector.add(lastBaseLabel);
		nameLabelVector.add(energyLabel);
		nameLabelVector.add(dmgLabel);
		nameLabelVector.add(soundLabel);
		
		dataLabelVector.add(timeData);
		dataLabelVector.add(livesLeftData);
		dataLabelVector.add(lastBaseData);
		dataLabelVector.add(energyData);
		dataLabelVector.add(dmgData);
		dataLabelVector.add(soundData);
		
		this.add(timeLabel);
		this.add(timeData);
		this.add(livesLeftLabel);
		this.add(livesLeftData);
		this.add(lastBaseLabel);
		this.add(lastBaseData);
		this.add(energyLabel);
		this.add(energyData);
		this.add(dmgLabel);
		this.add(dmgData);
		this.add(soundLabel);
		this.add(soundData);
	}
	
	public void styleLabels() {
		// style labels
		for (int i=0; i<nameLabelVector.size(); i++) 
		{  
			Label label = nameLabelVector.elementAt(i); 
			label.getAllStyles().setBgColor(ColorUtil.LTGRAY);
			label.getAllStyles().setFgColor(ColorUtil.BLUE);
			label.getAllStyles().setBgTransparency(0); 
		}
		
		for (int i=0; i<dataLabelVector.size(); i++) 
		{  
			Label label = dataLabelVector.elementAt(i); 
			label.getAllStyles().setBgColor(ColorUtil.LTGRAY);
			label.getAllStyles().setFgColor(ColorUtil.BLUE);
			label.getAllStyles().setBgTransparency(0); 
		}
	}
	@Override
	public void update (Observable o, Object arg) {
		// code here to update labels from the game/player-robot state data
		gw = (GameWorld) arg;
		
		this.timeData.setText(""+gw.getClockTicks()+"       ");
		this.livesLeftData.setText(""+gw.getLivesRemaining());
		this.lastBaseData.setText(""+gw.getLastBaseReached());
		this.energyData.setText(""+gw.getEnergyLevel());
		this.dmgData.setText(""+gw.getDamageLevel()+"     ");
		if (gw.getSound())
			this.soundData.setText("ON");
		else 
			this.soundData.setText("OFF");
		
		
	}

}
