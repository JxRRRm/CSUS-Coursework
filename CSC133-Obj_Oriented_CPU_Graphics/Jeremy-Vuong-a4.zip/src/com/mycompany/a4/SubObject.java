package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;

public class SubObject implements IDrawable {
	private Transform myTranslate, myRotate, myScale;
	private float size, rotateAngle;
	private Point bottomLeftPoint;
	private Point location;
    
	public SubObject(float objSize) {
		// TODO Auto-generated constructor stub {
		// TODO Auto-generated constructor stub
		 this.size = objSize;
	     this.rotateAngle = -20;
	     bottomLeftPoint = new Point((int) -size/2, (int) -size/2);
			

		myTranslate = Transform.makeIdentity();
        myRotate = Transform.makeIdentity();
        myScale = Transform.makeIdentity();
	}
	
	public Point getLocation() {
		float X = myTranslate.getTranslateX();
	    float Y = myTranslate.getTranslateY();
	        
	    location = new Point((int)X, (int)Y);
	        
	    return location;
	}
	/*
	public float getRotateAngle() {
		return rotateAngle;
	}

	public Transform getTranslate() {
        return myTranslate;
    }

    public Transform getRotate() {
        return myRotate;
    }

    public Transform getScale() {
        return myScale;
    }
	*/
	public void translate(float tx, float ty) {
		myTranslate.translate(tx, ty);
	}
	
	public void rotate(float angle, float px, float py) {
		angle = (float) Math.toRadians(angle);
        myRotate.rotate(angle, px, py);
        rotateAngle = (float) Math.toDegrees(angle);
    }
	
	public void scale(float sx, float sy) {
		myScale.scale(sx, sy);
	}

	@Override
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn, Transform gXform) {
		// TODO Auto-generated method stub
		int bLx = (int) bottomLeftPoint.getX() + pCmpRelPrnt.getX();
		int bLy = (int) bottomLeftPoint.getY() + pCmpRelPrnt.getY();
		int sz = (int) size;
		rotate(rotateAngle, 0, 0);
	    ///*
	    // Save the current Graphics transform
	    Transform gXformCopy = gXform.copy();
	    Transform LT = Transform.makeIdentity();
	    // Perform local origin transformation - part two
	    LT.translate(pCmpRelScrn.getX(), pCmpRelScrn.getY());
	    // Append LTs of the object onto the Graphics transform
	    LT.concatenate(myTranslate);
	    LT.concatenate(myRotate);
	    LT.concatenate(myScale);
	    
	    // Perform local origin transformation - part one
	    LT.translate(-pCmpRelScrn.getX(), -pCmpRelScrn.getY());
	    gXformCopy.concatenate(LT);

	    // Apply the transformed Graphics transform to the Graphics object
	    g.setTransform(gXformCopy);
	    //*/
		// Draw robot 
		g.setColor(ColorUtil.BLACK);
		g.fillRect(bLx, bLy, sz, sz);
		

		
		g.setTransform(gXform);
		
	}

}
