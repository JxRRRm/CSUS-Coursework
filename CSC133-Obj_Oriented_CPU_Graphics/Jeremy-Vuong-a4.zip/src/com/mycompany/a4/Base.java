package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Font;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;

public class Base extends Fixed implements IDrawable{
	private int sequenceNumber;
	private float[] xPoints, yPoints;
	private Point bRight, bLeft, top;
	private float topXf, topYf, leftXf, leftYf, rightXf, rightYf;
	//constructor
	public Base(final int objSize, final int objColor, int objSequenceNumber) 
	{
		super(objSize, objColor);
		this.sequenceNumber = objSequenceNumber;
		// TODO Auto-generated constructor stub
		top = new Point(0, getSize()/2);
		bLeft = new Point(-getSize()/2, -getSize()/2);
		bRight = new Point(getSize()/2, -getSize()/2);
		
		topXf = 0;
		topYf = getSize()/2; 
		leftXf = -getSize()/2;
		leftYf = -getSize()/2;
		rightXf = getSize()/2;
		rightYf =-getSize()/2;
		
	    xPoints = new float[] { topXf, leftXf, rightXf };
	    yPoints = new float[] { topYf, leftYf, rightYf };
	}
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " seqNum=" + sequenceNumber;
		return parentDesc + myDesc;
	}
	
	public int getSequenceNumber() {
		return sequenceNumber;
	}
	public float[] getXPoints() {
		return xPoints;
	}
	public float[] getYPoints() {
		return yPoints;
	}
	

	@Override
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn, Transform gXform) {
	    
	    int [] xPnts = new int[] { top.getX() + pCmpRelPrnt.getX(), bLeft.getX() + pCmpRelPrnt.getX(), 
	    					bRight.getX() + pCmpRelPrnt.getX() };
	    int [] yPnts = new int[] { top.getY() + pCmpRelPrnt.getY(), bLeft.getY() + pCmpRelPrnt.getY(), 
	    					bRight.getY() + pCmpRelPrnt.getY() };
	 	
	
	    ///*
	    // Save the current Graphics transform
	    Transform gXformCopy = gXform.copy();
	    Transform LT = Transform.makeIdentity();
	    // Perform local origin transformation - part two
	    LT.translate(pCmpRelScrn.getX(), pCmpRelScrn.getY());
	    // Append LTs of the object onto the Graphics transform
	    LT.concatenate(getTranslate());
	    LT.concatenate(getScale());
	    
	    // Perform local origin transformation - part one
	    LT.translate(-pCmpRelScrn.getX(), -pCmpRelScrn.getY());
	    gXformCopy.concatenate(LT);

	    // Apply the transformed Graphics transform to the Graphics object
	    g.setTransform(gXformCopy);
	    //*/
	   
	      
	    if (super.isSelected()) {
	    	g.setColor(ColorUtil.rgb(255, 0, 0));
			g.drawPolygon(xPnts, yPnts, 3);
			//drawn base number
	    	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_SMALL);
	    	g.setFont(font);
	    	g.setColor(ColorUtil.BLACK);
	    	g.scale(1, -1);
	    	g.drawString(""+getSequenceNumber(), pCmpRelPrnt.getX()-6, pCmpRelPrnt.getY()-385);
			  
	    } else {
	    	// Draw base
	    	g.setColor(getColor());
	    	g.fillPolygon(xPnts, yPnts, 3);
	    	// Draw base number
	    	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_SMALL);
	    	g.setFont(font);
	    	g.setColor(ColorUtil.WHITE);
	    	g.scale(1, -1);
	    	g.drawString(""+getSequenceNumber(), pCmpRelPrnt.getX()-6, pCmpRelPrnt.getY()-385);
	    }
	    
	    g.setTransform(gXform);
	}

	@Override
	public void handleCollision(GameObject otherObject) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
	    float px = pPtrRelPrnt.getX(); 
	    float py = pPtrRelPrnt.getY(); 
	    //float arrays used for transformPoint
	    float[] initPts = {px, py};
	    float[] transfPts = new float[2];
	    //inverse local transform values
	    float inverseTx = -getTranslate().getTranslateX();
	    float inverseTy = -getTranslate().getTranslateY();
	    float inverseSx = 1/getScale().getScaleX();
	    float inverseSy = 1/getScale().getScaleY();
	    //apply inverss local transformations
	    Transform inverseLT = Transform.makeIdentity();
	    inverseLT.scale(inverseSx, inverseSy);
	    inverseLT.translate(inverseTx, inverseTy);
	    inverseLT.transformPoint(initPts, transfPts);
	    px = transfPts[0];
	    py = transfPts[1];

	    int x1 = top.getX();
	    int y1 = top.getY();

	    int x2 = bLeft.getX();
	    int y2 = bLeft.getY();

	    int x3 = bRight.getX();
	    int y3 = bRight.getY();


	    //determinant
	    double detT = (y2 - y3)*(x1 - x3) + (x3 - x2)*(y1 - y3);
	    //barycentric coordinates
	    double alpha = ((y2 - y3)*(px - x3) + (x3 - x2)*(py - y3)) / detT;
	    double beta = ((y3 - y1)*(px - x3) + (x1 - x3)*(py - y3)) / detT;
	    double gamma = 1 - alpha - beta;
	    
	    return (alpha > 0 && beta > 0 && gamma > 0);
	}
	
	

}