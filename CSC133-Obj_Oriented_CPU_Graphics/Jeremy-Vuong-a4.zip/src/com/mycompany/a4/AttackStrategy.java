package com.mycompany.a4;

import com.codename1.util.MathUtil;

public class AttackStrategy implements IStrategy{
	private NonPlayerRobot nonPlayerRobot;
	private PlayerRobot playerRobot;
	
	public AttackStrategy(NonPlayerRobot npr, GameObjectCollection myCollection) {
		nonPlayerRobot = npr;
		
		IIterator myIter = myCollection.getIterator();
		
		while (myIter.hasNext()){
			GameObject myObject = myIter.getNext();
			if (myObject instanceof PlayerRobot) {
				playerRobot = (PlayerRobot) myObject;
				break;
			}
		}
	}

	public void apply() {
		float nprX = nonPlayerRobot.getTranslate().getTranslateX();
		float nprY = nonPlayerRobot.getTranslate().getTranslateY();
		float playerX = playerRobot.getTranslate().getTranslateX();
		float playerY = playerRobot.getTranslate().getTranslateY();
		double a, b;
		double angleA;

		

		a = playerX - nprX;
		b = playerY - nprY;

		//calculate ideal angle
		angleA = 90 - Math.toDegrees(MathUtil.atan2(b,a));
		System.out.println("angle = " + angleA);

		//set steering direction ??
		int oldHeading = nonPlayerRobot.getHeading();
		//set heading
		nonPlayerRobot.setHeading((int) -angleA);
		nonPlayerRobot.rotate(nonPlayerRobot.getHeading() -oldHeading, 0, 0);
		nonPlayerRobot.setStrategyID("Attack");
	}
	

}
