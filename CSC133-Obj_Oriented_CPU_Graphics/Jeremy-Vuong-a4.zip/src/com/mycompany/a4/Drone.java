package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Font;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;

public class Drone extends Movable implements IDrawable{
	private float[] xPoints, yPoints;
	private Point top, bLeft, bRight;
	//constructor
	public Drone(final int objSize, final int objColor, int objHeading, int objSpeed) {
		super(objSize, objColor, objHeading, objSpeed);
		// TODO Auto-generated constructor stub
		top = new Point(0, getSize()/2);
		bLeft = new Point(-getSize()/2, -getSize()/2);
		bRight = new Point(getSize()/2, -getSize()/2);
		
	    xPoints = new float[] { top.getX(), bLeft.getX(), bRight.getX() };
	    yPoints = new float[] { top.getY(), bLeft.getY(), bRight.getY() };
	}
	
	public float[] getXPoints() {
		return xPoints;
	}
	public float[] getYPoints() {
		return yPoints;
	}
	public Point getTopPoint() {
		return top;
	}
	


	@Override
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn, Transform gXform) {
		int[] xPnts = new int[] { top.getX() + pCmpRelPrnt.getX(), bLeft.getX() + pCmpRelPrnt.getX(), 
				bRight.getX() + pCmpRelPrnt.getX() };
		int[] yPnts = new int[] { top.getY() + pCmpRelPrnt.getY(), bLeft.getY() + pCmpRelPrnt.getY(), 
				bRight.getY() + pCmpRelPrnt.getY() };


		///*
		// Save the current Graphics transform
		Transform gXformCopy = gXform.copy();
		Transform LT = Transform.makeIdentity();
		// Perform local origin transformation - part two
		LT.translate(pCmpRelScrn.getX(), pCmpRelScrn.getY());
		// Append LTs of the object onto the Graphics transform
		LT.concatenate(getTranslate());
		LT.concatenate(getRotate());
		LT.concatenate(getScale());

		// Perform local origin transformation - part one
		LT.translate(-pCmpRelScrn.getX(), -pCmpRelScrn.getY());
		gXformCopy.concatenate(LT);

		// Apply the transformed Graphics transform to the Graphics object
		g.setTransform(gXformCopy);
		//*/
	      
	    g.setColor(getColor());
	    g.drawPolygon(xPnts, yPnts, 3);
	    // Draw front
    	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_SMALL);
    	g.setFont(font);
    	g.setColor(ColorUtil.BLACK);
    	g.scale(1, -1);
    	g.drawString("FRONT", pCmpRelPrnt.getX()-39, pCmpRelPrnt.getY()-415);
	    g.setTransform(gXform);
	}
	

}
