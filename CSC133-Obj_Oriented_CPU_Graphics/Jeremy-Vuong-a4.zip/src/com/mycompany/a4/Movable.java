package com.mycompany.a4;

import java.util.Random;

public class Movable extends GameObject {
	private int heading;
	private int speed;
	//private Random rand;
	//constructor
	public Movable(final int objSize, int objColor, int objHeading, int objSpeed) 
	{
		super(objSize, objColor);
		this.heading = objHeading;
		this.speed = objSpeed;
		//rand = new Random();
	}
	
	
	
	//getters
	public int getSpeed() 
	{
		return speed;
	}
	//
	public int getHeading() 
	{
		return heading;
	}
	
	//setters
	public void setSpeed(int newSpeed) 
	{
		this.speed = newSpeed;
	}
	
	public void setHeading(int newHeading) 
	{
		if (newHeading > 360) 
		{
			newHeading = newHeading - 360;
		}
		else if (newHeading < 0)
		{
			newHeading = 360 + newHeading;
		}
		
		this.heading = newHeading;
	}
	
	//move();method to move object 
	public void move(double time) {
		float theta = getHeading()+90; 
		float ogTx = getTranslate().getTranslateX();
		float ogTy = getTranslate().getTranslateY();
		
		float deltaX = (float) (Math.cos(Math.toRadians(theta)) * (getSpeed() * time)); 
		float deltaY = (float) (Math.sin(Math.toRadians(theta)) * (getSpeed() * time));
		
		float newX = ogTx + deltaX;
		float newY = ogTy + deltaY;
		float newTx = newX;
		float newTy = newY;
		
		//newX = Math.round(newX*10.0)/10.0;
		//newY = Math.round(newY*10.0)/10.0;
		int width = 931/2;
		int height = 631/2;
		
		//X
		if ((newX < 0) || (newX > width)) {
			if (newX < 0) {
				//this.setX(0+offset);
				newTx = 0;
			}
			else {
				//this.setX(width-offset);
				newTx = width;
				
			}
		}
		//Y
		if ((newY < 0) || (newY > height)) {
			if (newY < 0) {
				//this.setY(0+offset);
				newTy = 0;
			}
			else {
				//this.setY(1220-offset);
				newTy = height ;
			}
		}
		newTx -= ogTx;
		newTy -= ogTy;
		
		translate(newTx , newTy);
		if (this instanceof Drone) {
			if (getTranslate().getTranslateX() <= 0 || getTranslate().getTranslateX() >= width || getTranslate().getTranslateY() <= 0 || getTranslate().getTranslateY() >= height) {
				System.out.println("X= " +getTranslate().getTranslateX() +" Y" + getTranslate().getTranslateY());
				int oldHeading = getHeading();
				setHeading(getHeading() + 180);
				rotate(getHeading() - oldHeading, 0, 0);
				
			}
		}
	}
	
	//toString();method to return object description
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " heading=" + getHeading() 
				+ " speed=" + getSpeed();
		return parentDesc + myDesc;
	}


	@Override
	public void handleCollision(GameObject otherObject) {
		// TODO Auto-generated method stub
		
	}

}
