package com.mycompany.a4;

public interface ISteerable {
	public void steerLeft();
	public void steerRight();
}
