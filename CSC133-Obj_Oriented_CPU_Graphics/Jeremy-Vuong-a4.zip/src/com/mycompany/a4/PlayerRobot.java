package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Font;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;

public class PlayerRobot extends Robot implements IDrawable{
	private static PlayerRobot myRobot;
	private SubObject robotSubObj;
	
	public PlayerRobot(int objSize, int objColor, int objHeading, int objSpeed,
			int objMaximumSpeed, int objMaxDmg, int objLastBaseReached) {
		super(objSize, objColor, objHeading, objSpeed, objMaximumSpeed, objMaxDmg, objLastBaseReached);
		// TODO Auto-generated constructor stub
		robotSubObj = new SubObject(getSize()*0.5f);
	}

	public static PlayerRobot getRobot() {
		if (myRobot == null)
			myRobot = new PlayerRobot(100, ColorUtil.rgb(255, 0, 0), 0, 15, 200, 100, 1);
		return myRobot;
	}


	@Override
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn, Transform gXform) {		
		int bLx = (int) getBottomLeftPoint().getX() + pCmpRelPrnt.getX();
		int bLy = (int) getBottomLeftPoint().getY() + pCmpRelPrnt.getY();
		int size = getSize();
		 
		
	    ///*
	    // Save the current Graphics transform
	    Transform gXformCopy = gXform.copy();
	    Transform LT = Transform.makeIdentity();
	    // Perform local origin transformation - part two
	    LT.translate(pCmpRelScrn.getX(), pCmpRelScrn.getY());
	    // Append LTs of the object onto the Graphics transform
	    LT.concatenate(getTranslate());
	    LT.concatenate(getRotate());
	    LT.concatenate(getScale());
	    
	    // Perform local origin transformation - part one
	    LT.translate(-pCmpRelScrn.getX(), -pCmpRelScrn.getY());
	    gXformCopy.concatenate(LT);

	    // Apply the transformed Graphics transform to the Graphics object
	    g.setTransform(gXformCopy);
	    //*/
		// Draw robot 
		g.setColor(getColor());
		g.fillRect(bLx, bLy, size, size);
		// Draw front
    	Font font = Font.createSystemFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_SMALL);
    	g.setFont(font);
    	g.setColor(ColorUtil.BLACK);
    	g.scale(1, -1);
    	g.drawString("FRONT", pCmpRelPrnt.getX()-39, pCmpRelPrnt.getY()-455);
    	
    	// Draw sub-object
    	robotSubObj.draw(g, pCmpRelPrnt, pCmpRelScrn, gXformCopy);

		
		g.setTransform(gXform);
	}

}
