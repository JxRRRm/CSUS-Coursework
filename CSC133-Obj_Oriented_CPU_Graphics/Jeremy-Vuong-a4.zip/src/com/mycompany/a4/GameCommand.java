package com.mycompany.a4;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class GameCommand extends Command {
	private GameWorld gw;
	
	public GameCommand(String command, GameWorld gw) {
		super(command);
		this.gw = gw;
	}
	
@Override
	public void actionPerformed(ActionEvent ev) {
		switch(getCommandName()){
			case "Accelerate":
			   gw.accelerate();
			   break;
		   case "Brake":
			   gw.brake();
			   break;
		   case "Left":
			   gw.steerLeft();
			   break;
		   case "Right":
			   gw.steerRight();
			   break;
		   case "Tick":
			   gw.tick();
			   break;
		   case "d":
			   break;
		   case "Confirm Exit":
			   gw.exit();
			   break; 
		   case "Change Strategies":
			   gw.changeStrategies();
			   break;
		}
	}
}
