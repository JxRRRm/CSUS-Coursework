package com.mycompany.a4;
import java.lang.String;
import java.util.ArrayList;
import java.util.Vector;
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;


public abstract class GameObject implements ICollider{
	
	private final int size;
	private Point location;
	private int color;
	private Vector<GameObject> collisionVector = new Vector<GameObject>();
	private Transform myTranslate, myRotate, myScale;
	private float rotateAngle;
//constructor
	public GameObject(final int objSize, int objColor) {
		// TODO Auto-generated constructor stub
		this.size = objSize;
		this.color = objColor;
		
		rotateAngle = 0;
		
		myTranslate = Transform.makeIdentity();
        myRotate = Transform.makeIdentity();
        myScale = Transform.makeIdentity();
	}
	
	//functions to alter/check the collision vector
	public void addToCollisionVector(GameObject otherObject) {
        collisionVector.add(otherObject);
    }

    public void removeFromCollisionVector(GameObject otherObject) {
        collisionVector.remove(otherObject);
    }

    public boolean isInCollisionVector(GameObject otherObject) {
        return collisionVector.contains(otherObject);
    }
	

//getters
	public int getSize() {
		return size;
	}	
	
	public int getColor() {
		return color;
	}
	
	public Point getLocation() {
		float X = myTranslate.getTranslateX();
	    float Y = myTranslate.getTranslateY();
	        
	    location = new Point((int)X, (int)Y);
	        
	    return location;
	}
	
	public float getRotateAngle() {
		return rotateAngle;
	}


	public void setColor(int newColor) {
		this.color = newColor;
	}
	
	
	public Transform getTranslate() {
        return myTranslate;
    }

    public Transform getRotate() {
        return myRotate;
    }

    public Transform getScale() {
        return myScale;
    }

	public void translate(float tx, float ty) {
		myTranslate.translate(tx, ty);
	}
	
	public void rotate(float angle, float px, float py) {
		angle = (float) Math.toRadians(angle);
        myRotate.rotate(angle, px, py);
        rotateAngle = (float) Math.toDegrees(angle);
    }
	
	public void scale(float sx, float sy) {
		myScale.scale(sx, sy);
	}
//toString();method to return object description	
	public String toString() {
		String desc = "loc=" + myTranslate.getTranslateX() + ","+ myTranslate.getTranslateY() 
						+ " color=[" 
						+ ColorUtil.red(color) + ","  
						+ ColorUtil.green(color) + ","  
						+ ColorUtil.blue(color) + "]" 
						+ " size=" + size;
		return desc;
	}
//collidesWith()
	@Override
	public boolean collidesWith(GameObject otherObject) {
		Robot square;
		EnergyStation circle;
		Drone drone;
		Base base;
		//square-square
		if (otherObject instanceof Robot){
			float L1 = 0.3f*((Robot) this).getLeftX() +this.getTranslate().getTranslateX();
			float R1 = 0.3f*((Robot) this).getRightX() +this.getTranslate().getTranslateX();
			float T1 = 0.3f*((Robot) this).getTopY() +this.getTranslate().getTranslateY();
			float B1 = 0.3f*((Robot) this).getBottomY() +this.getTranslate().getTranslateY();
			float L2 = 0.3f*((Robot) otherObject).getLeftX() +otherObject.getTranslate().getTranslateX();
			float R2 = 0.3f*((Robot) otherObject).getRightX() +otherObject.getTranslate().getTranslateX();
			float T2 = 0.3f*((Robot) otherObject).getTopY() +otherObject.getTranslate().getTranslateY();
			float B2 = 0.3f*((Robot) otherObject).getBottomY() +otherObject.getTranslate().getTranslateY();
			if ( (R1 < L2) || (R2 < L1) || (T2 < B1) || (T1 < B2) )
				return false;
			else
				return true;
		//square-circle	
		} else if (otherObject instanceof EnergyStation) {
			
			square = (Robot) this;
			circle = (EnergyStation) otherObject;

			float lX = 0.3f*square.getLeftX() +square.getTranslate().getTranslateX();
			float rX = 0.3f*square.getRightX() +square.getTranslate().getTranslateX();
			float tY = 0.3f*square.getTopY() +square.getTranslate().getTranslateY();
			float bY = 0.3f*square.getBottomY() +square.getTranslate().getTranslateY();
			float cirX = circle.getLocation().getX();
			float cirY = circle.getLocation().getY();
			float radius = 0.3f*circle.getRadius();
			//first check corners
			// Find the closest corner
			float dx = Math.min(Math.abs(cirX - lX), Math.abs(cirX - rX));
			float dy = Math.min(Math.abs(cirY - tY), Math.abs(cirY - bY));
		    double d = Math.sqrt(dx * dx + dy * dy);

		    // Check if the closest corner is within the radius of the circle
		    if(d < radius) {
		    	return true;
		    }
			// if any side points intersect circle
			// left side (lX,tY) & (lX,bY)
		    d = distanceToSegment(cirX, cirY, lX, tY, lX, bY);
		    // right side (rX,tY) & (rX,bY)
		    d = Math.min(d, distanceToSegment(cirX, cirY, rX, tY, rX, bY));
		    // top side (lX,tY) & (rX,tY)
		    d = Math.min(d, distanceToSegment(cirX, cirY, lX, tY, rX, tY));
		    // bottom side (lX,bY) & (rX,bY)
		    d = Math.min(d, distanceToSegment(cirX, cirY, lX, bY, rX, bY));
		    if (d < radius) {
		        return true;
		    }
		//square-triangle
		} else if(this instanceof Robot && (otherObject instanceof Base || otherObject instanceof Drone)) {
			float[] xPoints, yPoints;
			float triangleTx, triangleTy;
			square = (Robot) this;
			if (otherObject instanceof Base) {
				base = (Base) otherObject;
				//get the arrays that store the local x and y points of the triangle
				xPoints = ((Base) base).getXPoints();
				yPoints = ((Base) base).getYPoints();
				//get the translations of the triangle
				triangleTx = base.getTranslate().getTranslateX();
				triangleTy = base.getTranslate().getTranslateY();
			}else {
				drone = (Drone) otherObject;
				xPoints = ((Drone) drone).getXPoints();
				yPoints = ((Drone) drone).getYPoints();
				triangleTx = drone.getTranslate().getTranslateX();
				triangleTy = drone.getTranslate().getTranslateY();
				}

			ArrayList<Float> squareX = new ArrayList<>();
			ArrayList<Float> squareY = new ArrayList<>();;
			int size = square.getSize();
			float pointX;
			float pointY;
			
			//squareX.add(square.getLeftX());
			//squareX.add(square.getRightX());
			//squareX.add(square.getTopY());
			//squareX.add(square.getBottomY());
			
			
			//get all points of the square and put them into a vector
			for (int i = 0; i < size; i++){
				//left points
				pointX = square.getLeftX();
				pointY = square.getTopY()-(i+1);
				squareX.add(pointX);
				squareY.add(pointY);
			
				//top points
				pointX = square.getLeftX()+(i+1);
				pointY = square.getTopY();
				squareX.add(pointX);
				squareY.add( pointY);
				//right points
				pointX = square.getRightX();
				pointY = square.getBottomY()+i;
				squareX.add(pointX);
				squareY.add( pointY);
				//bottom points
				pointX = square.getRightX()-i;
				pointY = square.getBottomY();
				squareX.add(pointX);
				squareY.add( pointY);;
			}
			
			//transform x and y points 
			//triangle
			// Transform x and y points of the triangle
			float tTx, tLx, tBx, tTy, tLy, tRy;
			tTx = 0.3f * xPoints[0] + triangleTx;
			tLx = 0.3f * xPoints[1] + triangleTx;
			tBx = 0.3f * xPoints[2] + triangleTx;
			tTy = 0.3f * yPoints[0] + triangleTy;
			tLy = 0.3f * yPoints[1] + triangleTy;
			tRy = 0.3f * yPoints[2] + triangleTy;
			
			float[] triX = new float[] { tTx, tLx, tBx };
			float[] triY = new float[] { tTy, tLy, tRy };
			/*
			for (int i = 0; i < xPoints.length; i++) {
				System.out.println("Triangle x = " + xPoints[i]);
			    xPoints[i] = 0.3f * xPoints[i] + triangleTx;
			    System.out.println("Translated x = " + xPoints[i]);
			}
			for (int i = 0; i < yPoints.length; i++) {
				System.out.println("Triangle y = " + yPoints[i]);
			    yPoints[i] = 0.3f * yPoints[i] + triangleTy;
			    System.out.println("Translated y = " + yPoints[i]);
			}
			*/
			//square
			for(int i = 0; i < squareX.size(); i++){
				squareX.set(i, 0.3f *squareX.get(i) +square.getTranslate().getTranslateX());
			}
			for(int i = 0; i < squareY.size(); i++){
				squareY.set(i, 0.3f *squareY.get(i) +square.getTranslate().getTranslateY());

			}
			
			return (contains(squareX, squareY, triX, triY));
		}


		return false;
		
	}
	
	//method that checks for square-triangle collision
	//detects if any point of the square is within the triangle
	public boolean contains(ArrayList<Float> squareX, ArrayList<Float> squareY, float[] triangleX, float[] triangleY) {
		//top points of triangle
		float x1 = triangleX[0];
		float y1 = triangleY[0];

		//bottom left point of triangle
		float x2 = triangleX[1];
		float y2 = triangleY[1];

		//bottom right point of triangle
		float x3 = triangleX[2];
		float y3 = triangleY[2];



		boolean result = false;
		
		for (int i = 0; i < squareX.size(); i++) {
			float px = squareX.get(i); 
			float py = squareY.get(i); 
			//determinant
			double detT = (y2 - y3)*(x1 - x3) + (x3 - x2)*(y1 - y3);
			//barycentric coordinates
			double alpha = ((y2 - y3)*(px - x3) + (x3 - x2)*(py - y3)) / detT;
			double beta = ((y3 - y1)*(px - x3) + (x1 - x3)*(py - y3)) / detT;
			double gamma = 1 - alpha - beta;
	    
			result = (alpha > 0 && beta > 0 && gamma > 0);
			if (result == true) {
				break;
			}
		}
		return result;
	}
	
	//calculates the distance from center of circle to side of square
	public double distanceToSegment(float cirX, float cirY, float lX, float tY, float lX2, float bY) {
	    double A = cirX - lX;
	    double B = cirY - tY;
	    double C = lX2 - lX;
	    double D = bY - tY;

	    double dot = A * C + B * D;
	    double len_sq = C * C + D * D;
	    double param = dot / len_sq;

	    double xx, yy;

	    if (param < 0) {
	        xx = lX;
	        yy = tY;
	    } else if (param > 1) {
	        xx = lX2;
	        yy = bY;
	    } else {
	        xx = lX + param * C;
	        yy = tY + param * D;
	    }

	    double dx = cirX - xx;
	    double dy = cirY - yy;
	    return Math.sqrt(dx * dx + dy * dy);
	}
	
	
	
	/*method to check if a line segment intersects with a square
	private boolean lineIntersectsSquare(int x1, int y1, int x2, int y2, int lX, int rX, int tY, int bY) {
		if (x1 >= lX && x1 <= rX && y1 >= tY && y1 <= bY) {
			return true;
		}
		if (x2 >= lX && x2 <= rX && y2 >= tY && y2 <= bY) {
			return true;
		}
		if (x1 < lX && x2 < lX) {
			return false;
		}
		if (x1 > rX && x2 > rX) {
			return false;
		}
		if (y1 < tY && y2 < tY) {
			return false;
		}
		if (y1 > bY && y2 > bY) {
			return false;
		}
		return true;
	}
	*/
}
	

