package com.mycompany.a4;

public abstract class Fixed extends GameObject implements ISelectable{
	private boolean selected;
	//constructor
	public Fixed(final int objSize, int objColor) {
		super(objSize, objColor);
		// TODO Auto-generated constructor stub
	}

    @Override
    public void setSelected(boolean b) {
        selected = b;
    }

    @Override
    public boolean isSelected() {
        return selected;
    }
/*
    @Override
    public void draw(Graphics g, Point pCmpRelPrnt) {
        int size = getSize();
        int x = (int) (pCmpRelPrnt.getX() + this.getX());
        int y = (int) (pCmpRelPrnt.getY() + this.getY());

        if (isSelected()) {
            g.setColor(ColorUtil.BLACK);
            g.drawArc(x, y, size, size, 0, 360);
        }

        g.setColor(getColor());
        g.fillArc(x, y, size, size, 0, 360);
    }
    */

}
