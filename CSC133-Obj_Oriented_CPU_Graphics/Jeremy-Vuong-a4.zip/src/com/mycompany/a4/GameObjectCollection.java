package com.mycompany.a4;

import java.util.Vector;

public class GameObjectCollection implements ICollection {
	
	private Vector<GameObject> myCollection;
	
	public GameObjectCollection() {
		myCollection = new Vector<GameObject>();
	}
	
	public void add(GameObject newObject) {
		myCollection.addElement(newObject);
	}
	
	public IIterator getIterator() {
		return new vectorIterator();
	}
	
	private class vectorIterator implements IIterator {
		private int currElementIndex;
		
		public vectorIterator() {
			currElementIndex = -1;
		}
		
		public boolean hasNext() {
			if (myCollection.size() <= 0) return false;
			if (currElementIndex == myCollection.size() - 1) 
				return false;
			return true;
		}
		
		public GameObject getNext () {
			currElementIndex ++;
			return(myCollection.elementAt(currElementIndex));
		}
		
	}//end private iterator class
}//end GameObjectCoollection class
