package com.mycompany.a4;

import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.Toolbar;
import java.util.Vector;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.util.UITimer;

public class Game extends Form implements Runnable{
	private GameWorld gw;
	private MapView mv; // new in A2
	private ScoreView sv; // new in A2
	private Vector<Button> buttonVector = new Vector<Button>();	
	private UITimer timer;
	private Command accelerate, steerLeft,changeStrat, brake, steerRight, pause, position;
	//sidemenu commands
	private Command exit, about, helpMenu, sound;
	// buttons
	private Button b1,b2, b3, b4, b5, b6, b7;
	private CheckBox soundToggle;
	private Toolbar myToolbar;

	
	public Game(){
		gw = new GameWorld(); // create “Observable” GameWorld
		mv = new MapView(gw); // create an “Observer” for the map
		sv = new ScoreView(); // create an “Observer” for the game/player-robot
		// state data
		gw.addObserver(mv); // register the map observer
		gw.addObserver(sv); // register the score observer
		// code here to create Command objects for each command,
		// add commands to side menu and title bar area, bind commands to keys, create
		// control containers for the buttons, add buttons to the control containers,
		// add commands to the buttons, and add control containers, MapView, and
		// ScoreView to the form
		
		
		// buttons
		b1 = new Button();
		b2 = new Button();
		b3 = new Button();
		b4 = new Button();
		b5 = new Button();
		b6 = new Button();
		b7 = new Button();
		// add buttons to vector	
		buttonVector.add(b1);
		buttonVector.add(b2);
		buttonVector.add(b3);
		buttonVector.add(b4);
		buttonVector.add(b5);
		buttonVector.add(b6);
		buttonVector.add(b7);
		
		// style buttons
		for (int i=0; i<buttonVector.size(); i++) 
		{  
		    Button button = buttonVector.elementAt(i); 
		    button.getAllStyles().setBgTransparency(255);
		    button.getAllStyles().setBgColor(ColorUtil.BLUE);
		    button.getAllStyles().setFgColor(ColorUtil.WHITE);
		    button.getAllStyles().setBorder(Border.createLineBorder(2,ColorUtil.BLACK));
		    button.getAllStyles().setPadding(Component.TOP, 4);
		    button.getAllStyles().setPadding(Component.BOTTOM, 4);
		    button.getAllStyles().setPadding(Component.LEFT, 2);
		    button.getAllStyles().setPadding(Component.RIGHT, 2);
		    button.getAllStyles().setAlignment(CENTER);
		}//end for
		//position 
		b6.getAllStyles().setBgTransparency(100);
		
		// commands
		accelerate = new GameCommand("Accelerate", gw);
		steerLeft = new GameCommand("Left", gw);
		changeStrat = new GameCommand("Change Strategies", gw);
		brake = new GameCommand("Brake", gw);
		steerRight = new GameCommand("Right", gw);
		pause = new PauseCommand(gw, this, b7);
		position = new PositionCommand(gw);
		//sidemenu commands
		exit = new SideMenuCommand("Exit", gw);
		about = new SideMenuCommand("About", gw);
		helpMenu = new SideMenuCommand("Help", gw);
		sound = new SideMenuCommand("Sound", gw);
		
		
		// set button commands
		b1.setCommand(accelerate);
		b2.setCommand(steerLeft);
		b3.setCommand(changeStrat);
		b4.setCommand(brake);
		b5.setCommand(steerRight);
		b6.setCommand(position);
		b7.setCommand(pause);
		
		b6.setEnabled(false);
		
		myToolbar = new Toolbar();
		setToolbar(myToolbar);
		myToolbar.setTitle("Robo-track Game");
		
		soundToggle = new CheckBox("Sound");
        soundToggle.setCommand(sound);
        soundToggle.setSelected(false);
        soundToggle.getAllStyles().setBgTransparency(255);
		
		myToolbar.addCommandToSideMenu(accelerate);
		myToolbar.addComponentToSideMenu(soundToggle);
		myToolbar.addCommandToSideMenu(about);
		myToolbar.addCommandToSideMenu(exit);
		//add an “empty” item to right side of title bar area
		myToolbar.addCommandToRightBar(helpMenu);

// containers
		// west
		Container wContainer = new Container(BoxLayout.y());
		wContainer.getAllStyles().setBgTransparency(50);
		wContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		wContainer.getAllStyles().setBorder(Border.createLineBorder(1,ColorUtil.GRAY));
		wContainer.getAllStyles().setPadding(Component.TOP, 350);
		wContainer.add(b1).add(b2).add(b3);
		// east
		Container eContainer = new Container(BoxLayout.y());
		eContainer.getAllStyles().setBgTransparency(50);
		eContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		eContainer.getAllStyles().setBorder(Border.createLineBorder(1,ColorUtil.GRAY));
		eContainer.getAllStyles().setPadding(Component.TOP, 350);
		eContainer.add(b4).add(b5);
		// north
		Container sContainer = new Container(BoxLayout.x());
		sContainer.getAllStyles().setBgTransparency(50);
		sContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		sContainer.getAllStyles().setBorder(Border.createLineBorder(1,ColorUtil.GRAY));
		sContainer.getAllStyles().setPadding(Component.LEFT, 900);
		sContainer.add(b6).add(b7);
		// cemter
		
		
// form		
		setLayout(new BorderLayout());
		this.add(BorderLayout.CENTER, mv).
			add(BorderLayout.SOUTH, sContainer).
			add(BorderLayout.NORTH, sv).
			add(BorderLayout.EAST, eContainer).
			add(BorderLayout.WEST, wContainer);
		this.setToolbar(myToolbar);
		
		// key listers
		this.addKeyListener('a', accelerate);
		this.addKeyListener('b', brake);
		this.addKeyListener('l', steerLeft);
		this.addKeyListener('r', steerRight);
		this.show();
		// code here to query MapView’s width and height and set them as world’s width and height
		gw.init(); // initialize world
		gw.setWidth(mv.getWidth()/2);
		gw.setHeight(mv.getHeight()/2);
		
		gw.createSounds();
		revalidate();
		timer  =  new UITimer(this);
		timer.schedule(20, true, this);
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		if (gw.getPaused() == false) {
	        gw.tick();
	    }
	}

	public void toggleCommands(boolean setting) {
		//commands
		position.setEnabled(!setting);
		accelerate.setEnabled(setting);
		steerLeft.setEnabled(setting);
		changeStrat.setEnabled(setting);
		brake.setEnabled(setting);
		steerRight.setEnabled(setting);
		//sidemenu commands
		myToolbar.findCommandComponent(accelerate).setEnabled(setting);
		soundToggle.setEnabled(setting);
		sound.setEnabled(setting);
	

		if (setting == true) {
			// add key listers
			this.addKeyListener('a', accelerate);
			this.addKeyListener('b', brake);
			this.addKeyListener('l', steerLeft);
			this.addKeyListener('r', steerRight);
			//buttons
			b6.setEnabled(false);
			b6.getAllStyles().setBgTransparency(100);
			soundToggle.getAllStyles().setBgTransparency(255);
			for (int i=0; i<buttonVector.size()-2; i++) 
			{  
			    Button button = buttonVector.elementAt(i);
			    button.setEnabled(true);
			    button.getAllStyles().setBgTransparency(255);
			}
			
		} else {		
			//remove key listers
			this.removeKeyListener('a', accelerate);
			this.removeKeyListener('b', brake);
			this.removeKeyListener('l', steerLeft);
			this.removeKeyListener('r', steerRight);
			//buttons
			b6.setEnabled(true);
			b6.getAllStyles().setBgTransparency(255);
			soundToggle.getAllStyles().setBgTransparency(0);
			
			for (int i=0; i<buttonVector.size()-2; i++) 
			{  
			    Button button = buttonVector.elementAt(i);
				button.setEnabled(false);
		    	button.getAllStyles().setBgTransparency(100);
			}
		}

	}
}

