package com.mycompany.a4;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.Transform.NotInvertibleException;
import com.codename1.ui.geom.Point;
import com.codename1.ui.plaf.Border;

public class MapView extends Container implements Observer {
	private GameWorld gw;
	Transform worldToND, ndToDisplay, theVTM ;
	private float winLeft, winBottom, winRight, winTop, winWidth, winHeight;
	
	public MapView(GameWorld gw) {
		super();
		// TODO Auto-generated constructor stub
		this.gw = gw;
		this.getAllStyles().setBorder(Border.createLineBorder(2,ColorUtil.rgb(255, 0, 0)));
		
		//initialize world window
		winLeft = 0;
		winBottom = 0;
		winRight = 931/2; //hardcoded value = this.getWidth()/2 (for the iPad skin)
		winTop = 639/2; //hardcoded value = this.getHeight()/2 (for the iPad skin)
		winWidth = winRight - winLeft;
		winHeight = winTop - winBottom;
	}

	@Override
	public void update (Observable o, Object arg) {
		// code here to call the method in GameWorld (Observable) that output the
		// game object information to the console
		gw = (GameWorld) arg;
		IIterator myIter = gw.getGameObjectCollection().getIterator();
		
		System.out.println("MAP: ");
		// display base description(s)
		while(myIter.hasNext()) {
			GameObject myObject = myIter.getNext();
			if (myObject instanceof Base) {
				System.out.println("Base: " + myObject.toString()); 
			}
			else if (myObject instanceof PlayerRobot) {
				System.out.println("Player Robot: " + myObject.toString()); 
			}
			else if (myObject instanceof Robot) {
				System.out.println("NonPlayerRobot: " + myObject.toString()); 
			}
			else if (myObject instanceof Drone) {
				System.out.println("Drone: " + myObject.toString()); 
			}
			else if (myObject instanceof EnergyStation) {
				System.out.println("EnergyStation: " + myObject.toString()); 
			}
		}
		System.out.println();
		this.repaint();
		
	}
	

	@Override
	public void paint (Graphics g) {
		super.paint(g);
		//...[calculate winWidth and winHeight]
		// construct the Viewing Transformation Matrix
		worldToND = buildWorldToNDXform(winWidth, winHeight, winLeft, winBottom);
		ndToDisplay = buildNDToDisplayXform(this.getWidth(), this.getHeight());
		theVTM = ndToDisplay.copy();
		theVTM.concatenate(worldToND); 
		// worldToND will be applied first to points!
		// concatenate the VTM onto the g’s current transformation (do not forget to apply “local origin” transformation)
		Transform gXform = Transform.makeIdentity();
		g.getTransform(gXform);
		gXform.translate(getAbsoluteX(),getAbsoluteY()); //local origin xform (part 2)
		gXform.concatenate(theVTM); //VTM xform
		gXform.translate(-getAbsoluteX(),-getAbsoluteY()); //local origin xform (part 1)
		g.setTransform(gXform);
		
		// tell each shape to draw itself using the g (which contains the VTM)
		Point pCmpRelPrnt = new Point(this.getX(), this.getY());
		Point pCmpRelScrn = new Point(getAbsoluteX(),getAbsoluteY());
		
		IIterator itr = gw.getGameObjectCollection().getIterator();
		while(itr.hasNext()) {
			GameObject obj = itr.getNext();
			if (obj instanceof IDrawable) {
				((IDrawable) obj).draw(g, pCmpRelPrnt, pCmpRelScrn, gXform);
			}
		}
		
		g.resetAffine() ;
	}
	
	private Transform buildWorldToNDXform(float winWidth, float winHeight, float winLeft, float winBottom){
		Transform tmpXfrom = Transform.makeIdentity();
		tmpXfrom.scale( (1/winWidth) , (1/winHeight) );
		tmpXfrom.translate(-winLeft,-winBottom);
		return tmpXfrom;
	}
		
	private Transform buildNDToDisplayXform (float displayWidth, float displayHeight){
		Transform tmpXfrom = Transform.makeIdentity();
		tmpXfrom.translate(0, displayHeight);
		tmpXfrom.scale(displayWidth, -displayHeight);
		return tmpXfrom;
	}
		//...[other methods of CustomContainer]

	/*
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Point pCmpRelPrnt = new Point(this.getX(), this.getY());
		
		IIterator itr = gw.getGameObjectCollection().getIterator();
		while(itr.hasNext()) {
			GameObject obj = itr.getNext();
			if (obj instanceof IDrawable) {
				((IDrawable) obj).draw(g, pCmpRelPrnt);
			}
		}
	}
	*/

	@Override
	public void pointerPressed(int x, int y) {
		//idk if used or not but contains has this as a parameter
		Point pCmpRelPrnt = new Point(getX(), getY());
		
		//convert the pointer coordinates from screen space to display space
		float px = x - this.getAbsoluteX();
		float py = y - this.getAbsoluteY();
		//float arrays used to transform point
		float[] initPts = {px, py};
	    float[] transfPts = new float[2];
	    
	    //apply the inverse of the VTM to the pointer coordinates in display space
	    Transform inverseVTM = Transform.makeIdentity();
	    try {
	    	theVTM.getInverse(inverseVTM);
	    	inverseVTM.transformPoint(initPts, transfPts);
	    } catch (NotInvertibleException e) {
	    	e.printStackTrace();
	    }
	    
	    //transformed point
	    Point pPtrRelPrnt = new Point((int) transfPts[0], (int) transfPts[1]);

	    
		if (gw.getPaused() == true) {	  
			
		    // check if there is a Fixed object at the pointer location
		    IIterator itr = gw.getGameObjectCollection().getIterator();
		    while(itr.hasNext()) {
		        GameObject obj = itr.getNext();
		        if (obj instanceof ISelectable) {
		        	if (gw.getPosFlag() == false) {
		        		
		        		if (((ISelectable) obj).contains(pPtrRelPrnt, pCmpRelPrnt)) {
		        			// select the Fixed object
		        			((ISelectable) obj).setSelected(true);
		        		}else {
		        			//unselect all other objects
		        			((ISelectable) obj).setSelected(false);
		        		}
		        	}else {
		        		if (((ISelectable) obj).isSelected() == true) {
		        			//original translates
		        			float ogX = obj.getTranslate().getTranslateX();
		        			float ogY = obj.getTranslate().getTranslateY();
		        			//new position
		        		    px = transfPts[0];
		        		    py = transfPts[1];
		        		    //translate to new position
		        			obj.translate(px-ogX, py-ogY);

		        			gw.togglePosFlag();
		        		}
		        	}
		        	//repaint the MapView to show the selected object
		        	this.repaint();
		        }//end if
		    }//end while 	
		}//end if
	}//end pointerPressed()
	
}
