package com.mycompany.a4;

public interface ICollection {
	
	public void add(GameObject newObject);
	public IIterator getIterator();
}
