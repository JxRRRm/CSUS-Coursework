package com.mycompany.a1;

import com.codename1.charts.util.ColorUtil;

public class Robot extends Movable implements ISteerable{
	private int steeringDirection = 0;
	private int maximumSpeed;
	private int energyLevel = 50; 
	private int energyConsumptionRate = 5;
	private int damageLevel = 0;
	private int lastBaseReached = 1; 
	private final int maxDmg = 100;

	//constructor
	public Robot(final int objSize, double locX, double locY, int objColor, int objHeading, 
					int objSpeed, int objMaximumSpeed) 
	{
		super(objSize, locX, locY, objColor, objHeading, objSpeed);
		this.maximumSpeed = objMaximumSpeed;
		
	}
	
	
	// steer left
	public void steerLeft() {
		if (steeringDirection > -40)
		setSteeringDirection(steeringDirection -5);
	}
	
	// steer right
	public void steerRight() {
		if (this.steeringDirection < 40)
		setSteeringDirection(steeringDirection + 5);
	}
	
	
	// getters 
	public int getLastBaseReached() {
		return lastBaseReached;
	}
	public int getMaximumSpeed() {
		return maximumSpeed;
	}
	public int getEnergyLevel() {
		return energyLevel;
	}
	public int getDamageLevel() {
		return damageLevel;
	}
	public int getMaxDmg() {
		return maxDmg;
	}
	public int getSteeringDirection() {
		return steeringDirection;
	}
	public int getEnergyConsumptionRate() {
		return energyConsumptionRate;
	}

	//setters
	public void setLastBaseReached(int newBaseReached) {
		this.lastBaseReached =  newBaseReached;
	}
	public void setEnergyLevel(int nrgLevel) {
		this.energyLevel = nrgLevel;
	}
	public void setDamageLevel(int dmgLevel) {
		this.damageLevel = dmgLevel;
	}
	public void setSteeringDirection(int newDirection) {
		this.steeringDirection = newDirection;
	}
	
	//toString
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " maxSpeed=" + maximumSpeed 
							+ " steeringDirection=" + getSteeringDirection()
							+ " energyLevel=" + getEnergyLevel()
							+ " damageLevel=" + getDamageLevel();
		return parentDesc + myDesc;
	}


	
}
