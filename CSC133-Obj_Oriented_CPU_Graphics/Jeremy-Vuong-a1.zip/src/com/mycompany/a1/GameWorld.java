package com.mycompany.a1;

import com.codename1.charts.util.ColorUtil;
import java.util.Random;
import java.util.Vector;

public class GameWorld {
	//game state data
	private int clockTicks = 0;
	private int livesRemaining = 3;
	//game world dimensions
	private final double width = 1024.0;
	private final double height = 768.0;
	//other game data
	private final int lastBase = 4;
	private final int robotCollisionDmg = 20;
	private final int droneCollisionDmg = robotCollisionDmg/2;
	
	// vectors to store game world objects
	private Vector<Base> baseVector = new Vector();					//base vector
	private Vector<Robot> robotVector = new Vector();				//robot vector
	private Vector<Drone> droneVector = new Vector();				//drone vector
	private Vector<EnergyStation> eStationVector = new Vector();	//energy station vector
	private Vector<Movable> mObjVector = new Vector();				//movable object vector
	// private Vector<Fixed> fObjVector = new Vector();				//fixed object vector
	// random generated numbers
	private Random rand = new Random();								//rand
	private int randOne = randomInt();					//random number between 10 and 50; used for drone instantiation
	private int randTwo = randomInt();
	// objects
	private Base baseOne, baseTwo, baseThree, baseFour;				
	private Robot playerRobot;
	private Drone droneOne, droneTwo;
	private EnergyStation stationOne, stationTwo;
	
	public void init() {
		//code here to create the 
		  //initial game objects/setup 
		baseOne = new Base(10, 200.0, 200.0, ColorUtil.rgb(0, 0, 255), 1);
		baseTwo = new Base(10, 200.0, 800.0, ColorUtil.rgb(0, 0, 255), 2);
		baseThree = new Base(10, 700.0, 800.0, ColorUtil.rgb(0, 0, 255), 3);
		baseFour = new Base(10, 900.0, 400.0, ColorUtil.rgb(0, 0, 255), 4);
		
		playerRobot = new Robot(40, baseOne.getX(), baseOne.getY(), ColorUtil.rgb(255, 0, 0), 0, 10, 50);
		
		droneOne = new Drone(10 + rand.nextInt(41), randomDouble(width), randomDouble(height), 
								ColorUtil.rgb(255, 175, 175), rand.nextInt(360), 5 + rand.nextInt(11));
		droneTwo = new Drone(10 + rand.nextInt(41), randomDouble(width) + 0.0, randomDouble(height), 
								ColorUtil.rgb(255, 175, 175), rand.nextInt(360), 5 + rand.nextInt(11));

		stationOne = new EnergyStation(randOne, randomDouble(width), randomDouble(height), ColorUtil.rgb(0, 255, 0), randOne);
		stationTwo = new EnergyStation(randTwo, randomDouble(width), randomDouble(height), ColorUtil.rgb(0, 255, 0), randTwo);	
		
		//add objects into vectors
		baseVector.add(baseOne);
		baseVector.add(baseTwo);
		baseVector.add(baseThree);
		baseVector.add(baseFour);
		robotVector.add(playerRobot);
		droneVector.add(droneOne);
		droneVector.add(droneTwo);
		eStationVector.add(stationOne);
		eStationVector.add(stationTwo);
		// movable objects
		mObjVector.add(playerRobot);
		mObjVector.add(droneOne);
		mObjVector.add(droneTwo);
		
		
	}
	// additional methods here to 
	 // manipulate world objects and 
	 // related game state data 
	
// check game conditions
	
	
	
//randomDouble();method to return rounded random double for drone location====================================|
	public double randomDouble(double dbl) 
	{
		double randomDouble;
		randomDouble = rand.nextDouble() * (dbl - 0.0) + 0.0;
		randomDouble = (Math.round(randomDouble*10.0)/10.0);
		return randomDouble;
	}//end randomDouble()=====================================================================================|
	
//randomInt();method to generate a random integer between 10 and 50===========================================|
	public int randomInt() 
	{
		int randomInt = 10 + rand.nextInt(41);
		return randomInt;
	}//end randomInt()========================================================================================|
	
//win();method to handle win condition========================================================================|
	public void win() {
		System.out.println("Game over, you win! Total time:  " + clockTicks + "\n");
		livesRemaining = 3;
		clockTicks = 0;
		exit();
		
	}
//died();method to handle robot sustaining too much damage or robot running out of energy=====================|
	public void died() 
	{
		livesRemaining -= 1;
		if (livesRemaining == 0) 
		{
			System.out.println("Game over, you failed!”");
			//reset game
			livesRemaining = 3;
			clockTicks = 0;
			exit();
		}
		else
		{
			//restart with new life
			playerRobot.setX(baseOne.getX());
			playerRobot.setY(baseOne.getY());
			playerRobot.setColor(ColorUtil.rgb(255, 0, 0));
			playerRobot.setDamageLevel(0);
			playerRobot.setEnergyLevel(50);
			playerRobot.setHeading(0);
			playerRobot.setSpeed(10);
			playerRobot.setLastBaseReached(1);
			playerRobot.setSteeringDirection(0);
			
			
		}
	}//end died()=============================================================================================|
	
//tick();method to increment clock ticks======================================================================|
	public void tick() 
	{
		System.out.println("CLOCK HAS TICKED\n");
		//if robot moves
		if (playerRobot.getEnergyLevel() != 0 && playerRobot.getDamageLevel() != playerRobot.getMaxDmg()) 
		{
			playerRobot.setHeading(playerRobot.getHeading() + playerRobot.getSteeringDirection());
		}//end if
		else
		{
			died();
			
		}
		
		// update drone headings
		for (int i=0; i<droneVector.size(); i++) 
		{  
		    Drone drone = droneVector.elementAt(i); 
		    drone.setHeading(droneOne.getHeading() + (-5 + rand.nextInt(6)));
		}//end for
		
		// move objects
		for (int i=0; i<mObjVector.size(); i++) 
		{  
		    Movable mObj = mObjVector.elementAt(i); 
		    mObj.move();
		}//end for
		
		// consume energy
		consumeEnergy();
		
		// increment game clock
		clockTicks += 1;
	}//end tick()=============================================================================================|
	
//accelerate();method to accelerate===========================================================================|
	public void accelerate() 
	{
		System.out.println("Player robot has accelerated\n");
			playerRobot.setSpeed(playerRobot.getSpeed()+10);
		
		if (playerRobot.getSpeed() > playerRobot.getMaximumSpeed())
			playerRobot.setSpeed(playerRobot.getMaximumSpeed());
	}//end accelerate()=======================================================================================|
	
//brake();method to brake=====================================================================================|
	public void brake() 
	{
		System.out.println("BRAKES ARE APPLIED\n");
		playerRobot.setSpeed(playerRobot.getSpeed() - 10);
		if (playerRobot.getSpeed() < 0)
			playerRobot.setSpeed(0);
	}//end brake()=============================================================================================|
	
//method to steer left=========================================================================================|
	public void steerLeft() 
	{
		System.out.println("STEERING WHEEL HAS TURNED LEFT\n");
		playerRobot.steerLeft();
	}//end steerLeft()=========================================================================================|
	
//steerRight();method to steer right===========================================================================|
	public void steerRight() 
	{
		System.out.println("STEERING WHEEL HAS TURNED RIGHT\n");
		playerRobot.steerRight();
	}//end steerRight()========================================================================================|
	
//robotCollision();method to pretend that a robot collision has occurred=======================================|
	public void robotCollision() 
	{	
		double maxDmg = (double)playerRobot.getMaxDmg();							// robot's max damage
		double percent = (robotCollisionDmg+playerRobot.getDamageLevel())/maxDmg;	// percent of robot's max damage
		double newSpeed = playerRobot.getSpeed() - (playerRobot.getSpeed() * percent);	// new speed of robot
		// collision message
		System.out.println("THERE HAS BEEN A COLLISION WITH A ROBOT!\n");
		// take damage
		playerRobot.setDamageLevel(playerRobot.getDamageLevel() + robotCollisionDmg);
		// update speed
		playerRobot.setSpeed((int)newSpeed);
		// check if able to move
		
		if (playerRobot.getDamageLevel() >= (int)maxDmg) 
		{
			died();
		}//end if
		else 
		{
			// make color of robot lighter
			int r = ColorUtil.red(playerRobot.getColor())-25;
			int g = ColorUtil.green(playerRobot.getColor())-25;
			int b = ColorUtil.blue(playerRobot.getColor())-25;
			if (r<=0) {r=0;}
			if (g<=0) {g=0;}
			if (b<=0) {b=0;}
			int newColor = ColorUtil.rgb(r, g, b);
			playerRobot.setColor(newColor);
		}//end else
	}//end robotCollision()====================================================================================|
	
//baseCollision();method to handle base collision==============================================================|
	public void baseCollision(int x) {
		System.out.println("COLLISION WITH A BASE!\n");
		if (x == playerRobot.getLastBaseReached()+1)
		{
			playerRobot.setLastBaseReached(x);
			if (playerRobot.getLastBaseReached()==lastBase)
			{
				win();
			}
		}
	}//end baseCollision()=====================================================================================|
	
//stationCollision();method to handle energy station collision ================================================|
		public void stationCollision() 
		{
			//force collision with station one
			playerRobot.setX(stationOne.getX());
			playerRobot.setY(stationOne.getY());
			
			//force collision with station two
			//playerRobot.setX(stationTwo.getX());
			//playerRobot.setY(stationTwo.getY());
			
			//check for energy station collision
			for (int i=0; i<eStationVector.size(); i++) 
			{ 	    
			    EnergyStation station = eStationVector.elementAt(i); 
			    if (playerRobot.getX() == station.getX() && playerRobot.getY() == station.getY()) 
			    {
			    	// collision message
			    	System.out.println("COLLISION WITH ENERGY STATION " + i+1 + "!\n");
			    	// make color light
					int r = ColorUtil.red(station.getColor()) - 155;
					int g = ColorUtil.green(station.getColor()) - 155; 
					int b = ColorUtil.blue(station.getColor()) - 155; 
					if (r <= 0) {r = 0;}
					if (g <= 0) {g = 0;}
					if (b <= 0) {b = 0;}
					int newColor = ColorUtil.rgb(r, g, b);
					station.setColor(newColor);
					
					// absorb energy and drain station's capacity
					//stationOne
					playerRobot.setEnergyLevel(playerRobot.getEnergyLevel() + station.getCapacity());
					station.drainCapacity();
				
					// destroy energy station collided with and generate new energy station
					int randomNumber = randomInt();
					EnergyStation newStation = new EnergyStation(randomNumber, randomDouble(width), randomDouble(height), 
												ColorUtil.rgb(0, 255, 0), randomNumber);
					eStationVector.add(newStation);
			    }//end if
			}//end for
		}//end stationCollision()==============================================================================
		
//droneCollision();method to handle drone collision============================================================
		public void droneCollision() 
		{
			//force collision with station one
			playerRobot.setX(droneVector.elementAt(0).getX());
			playerRobot.setY(droneVector.elementAt(0).getY());
						
			//force collision with station two
			//playerRobot.setX(droneVector.elementAt(1).getX());
			//playerRobot.setY(droneVector.elementAt(1).getY());
			
			//check for energy drone collision
			for (int i=0; i<droneVector.size(); i++) 
			{ 	    
				Drone drone = droneVector.elementAt(i); 
				if (playerRobot.getX() == drone.getX() && drone.getY() == drone.getY()) 
				{
				// collision message
				System.out.println("COLLISION WITH DRONE " + i+1 + "!\n");
				
				double maxDmg = (double)playerRobot.getMaxDmg();							// robot's max damage
				double percent = (droneCollisionDmg+playerRobot.getDamageLevel())/maxDmg;	// percent of robot's max damage
				double newSpeed = playerRobot.getSpeed() - (playerRobot.getSpeed() * percent);	// new speed of robot
				
				// take damage
				playerRobot.setDamageLevel(playerRobot.getDamageLevel() + droneCollisionDmg);
				// update speed
				playerRobot.setSpeed((int)newSpeed);
				// check if able to move
				if (playerRobot.getDamageLevel() >= (int)maxDmg) 
				{
					died();
						if (livesRemaining == 0) {
							System.out.println("Game over, you failed!”");
							exit();
						}
					}//end if
					else 
					{
						// make color of robot lighter
						int r = ColorUtil.red(playerRobot.getColor())-15;
						int g = ColorUtil.green(playerRobot.getColor())-15;
						int b = ColorUtil.red(playerRobot.getColor())-15;
						if (r<0) {r=0;}
						if (g<0) {g=0;}
						if (b<0) {b=0;}
						int newColor = ColorUtil.rgb(r, g, b);
						playerRobot.setColor(newColor);
					}//end else
					}//end if
			}//end for
		}//end droneCollision()==================================================================================
		
//consumeEnergy();method to consume energy=======================================================================
	public void consumeEnergy() 
	{
		playerRobot.setEnergyLevel(playerRobot.getEnergyLevel() - playerRobot.getEnergyConsumptionRate());
	}//end consumeEnergy()=======================================================================================

//display();method to display current game/player-robot state values=============================================
	public void display() 
	{
		System.out.println("GAME STATE DETAILS: ");
		System.out.println("Lives Remaining: " + livesRemaining);
		System.out.println("Elapsed Time: " + clockTicks);
		System.out.println("Last Base Reached: " + playerRobot.getLastBaseReached());
		System.out.println("Robot Energy Level: " + playerRobot.getEnergyLevel());
		System.out.println("Robot Damage Level: " + playerRobot.getDamageLevel() + "/" + playerRobot.getMaxDmg());
		System.out.println();
	}//end display()==============================================================================================

//map();method to display the current world description===========================================================
	public void map() 
	{
		System.out.println("MAP: ");
		// display base description(s)
		for (int i=0; i<baseVector.size(); i++) 
		{  
			Base base = baseVector.elementAt(i); 
			System.out.println("Base: " + base.toString());     
		}//end for
		
		//display robot description(s)
		for (int i=0; i<robotVector.size(); i++) 
		{ 	    
			Robot robot = robotVector.elementAt(i); 
			System.out.println("Robot: " + robot.toString());
		}//end for
		
		//display drone description(s)
		for (int i=0; i<droneVector.size(); i++) 
		{ 	    
		    Drone drone = droneVector.elementAt(i); 
		    System.out.println("Drone: " + drone.toString());
		}//end for
		
		//display energy station description(s)
		for (int i=0; i<eStationVector.size(); i++) 
		{ 	    
			EnergyStation station = eStationVector.elementAt(i); 
		    System.out.println("EnergyStation: " + station.toString());
		}//end for 
		
		System.out.println();
	}//end map()====================================================================================================
	
//exit();method to terminate the program============================================================================
		public void exit() 
		{
			System.out.println("EXITING GAME...");
			System.exit(0);
		}//end exit()===============================================================================================
//confirmExit();gets confirmation that the user wants to exit
		public void confirmExit() {
			System.out.println("Do you want to exit? Press 'y' to confirm or 'n' to cancel");
		}
		
}//GameWorld
