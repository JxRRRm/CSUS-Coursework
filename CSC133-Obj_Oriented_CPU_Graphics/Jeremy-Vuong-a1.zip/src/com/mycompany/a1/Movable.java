package com.mycompany.a1;

public class Movable extends GameObject {
	private int heading;
	private int speed;
	
	// constructor
	public Movable(final int objSize, double locX, double locY, int objColor, int objHeading, int objSpeed) 
	{
		super(objSize, locX, locY, objColor);
		this.heading = objHeading;
		this.speed = objSpeed;
	}
	
	
	// move/change locations
	public void move() {
		double theta = 90 - this.getHeading(); 
		
		
		Math.toRadians(theta);
		double deltaX = Math.cos(Math.toRadians(theta))*getSpeed(); 
		double deltaY = Math.sin(Math.toRadians(theta))*getSpeed();
		
		double newX = getX() + deltaX;
		double newY = getY() + deltaY;
		newX = Math.round(newX*10.0)/10.0;
		newY = Math.round(newY*10.0)/10.0;
		this.setX(newX);
		this.setY(newY);
	}
	
	// returns speed of object
	public int getSpeed() {
		return speed;
	}
	//sets speed of object
	public void setSpeed(int newSpeed) {
		this.speed = newSpeed;
	}

	public int getHeading() {
		return heading;
	}

	public void setHeading(int newHeading) {
		if (newHeading > 360) 
		{
			newHeading = newHeading - 360;
		}
		else if (newHeading < 0)
		{
			newHeading = 360 + newHeading;
		}
		
		this.heading = newHeading;
	}
	
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " heading=" + getHeading() 
				+ " speed=" + getSpeed();
		return parentDesc + myDesc;
	}
	

}
