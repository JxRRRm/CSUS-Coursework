package com.mycompany.a1;

import com.codename1.ui.events.ActionListener; 
import com.codename1.ui.Label; 
import com.codename1.ui.TextField; 
import com.codename1.ui.events.ActionEvent; 
import java.lang.String; 

import com.codename1.ui.Form;
public class Game extends Form {
	private GameWorld gw;
	
	public Game() {
		gw = new GameWorld();
		gw.init();
		play();
	}
	
	private void play() { 
		  // code here to accept and  
		  // execute user commands that 
		  // operate on the game world 
		//(refer  to  “Appendix  - CN1 
		//Notes” for accepting  
		//keyboard  commands  via  a  text 
		//field located on the form)  
		Label myLabel=new Label("Enter a Command:"); 
		 this.addComponent(myLabel); 
		 final TextField myTextField=new TextField(); 
		 this.addComponent(myTextField); 
		 this.show(); 
		 
		 
		 myTextField.addActionListener(new ActionListener(){ 
		 
		  public void actionPerformed(ActionEvent evt) { 
		     
		  String sCommand=myTextField.getText().toString(); 
		  myTextField.clear(); 
		  switch (sCommand.charAt(0)) { 
		   //add code to handle rest of the commands  
		   default:
			   System.out.println("ERROR! Unknown Command");
			   break;
		   case 'a':
			   gw.accelerate();
			   break;
		   case 'b':
			   gw.brake();
			   break;
		   case 'l':
			   gw.steerLeft();
			   break;
		   case 'r':
			   gw.steerRight();
			   break;
		   case 'c':
			   gw.robotCollision();
			   break;
		   case '1':
			   gw.baseCollision(1);
			   break;
		   case '2':
			   gw.baseCollision(2);
			   break;
		   case '3':
			   gw.baseCollision(3);
			   break;
		   case '4':
			   gw.baseCollision(4);
			   break;
		   case '5':
			   gw.baseCollision(5);
			   break;
		   case '6':
			   gw.baseCollision(6);
			   break;
		   case '7':
			   gw.baseCollision(7);
			   break;
		   case '8':
			   gw.baseCollision(8);
			   break;
		   case '9':
			   gw.baseCollision(9);
			   break;
		   case 'e':
			   gw.stationCollision();
			   break;
		   case 'g':
			   gw.droneCollision();
			   break;
		   case 't':
			   gw.tick();
			   break;
		   case 'd':
			   gw.display();
			   break;
		   case 'm':
			   gw.map();
			   break;
		   case 'x':
			   gw.confirmExit();
			   break; 
		   case 'y':
			   gw.exit();
			   break;
		   case 'n':
			   break;
		  } //switch 	
		 } //actionPerformed 
		    } //new ActionListener() 
		 ); //addActionListener 
		 } //play 	
	
}