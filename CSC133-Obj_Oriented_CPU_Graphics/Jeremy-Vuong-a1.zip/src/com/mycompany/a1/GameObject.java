package com.mycompany.a1;
import java.lang.String;

import com.codename1.charts.util.ColorUtil;

public abstract class GameObject {
	
	private final int size;
	private double X, Y;
	private int color;
	
	
	public GameObject(final int objSize, double locX, double locY, int objColor) {
		// TODO Auto-generated constructor stub
		this.size = objSize;
		this.X = locX;
		this.Y = locY;
		this.color = objColor;
	}

	public int getSize() {
		return size;
	}	
	
	public int getColor() {
		return color;
	}
	
	public void setColor(int newColor) {
		this.color = newColor;
	}

	public double getX() {
		return X;
	}

	public void setX(double x) {
		this.X = x;
	}

	public double getY() {
		return Y;
	}

	public void setY(double y) {
		this.Y = y;
	}
	
	public String toString() {
		String desc = "loc=" + getX() + ","+ getY() 
						+ " color=[" 
						+ ColorUtil.red(color) + ","  
						+ ColorUtil.green(color) + ","  
						+ ColorUtil.blue(color) + "]" 
						+ " size=" + size;
		return desc;
	}

}

