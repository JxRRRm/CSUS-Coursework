package com.mycompany.a1;

public class Drone extends Movable {

	public Drone(final int objSize, double locX, double locY, final int objColor, int objHeading, int objSpeed) {
		super(objSize, locX, locY, objColor, objHeading, objSpeed);
		// TODO Auto-generated constructor stub
	}
	
	

}
