package com.mycompany.a1;

public class Fixed extends GameObject {

	public Fixed(final int objSize, final double locX, final double locY, int objColor) {
		super(objSize, locX, locY, objColor);
		// TODO Auto-generated constructor stub
	}

}
