package com.mycompany.a1;

public class EnergyStation extends Fixed {
	private int capacity;

	public EnergyStation(final int objSize, final double locX, final double locY, int objColor, int objCapacity) {
		super(objSize, locX, locY, objColor);
		this.capacity = objCapacity;

	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public void drainCapacity() {
		this.capacity = 0;
	}
	
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " capacity=" + capacity;
		return parentDesc + myDesc;
	}

}