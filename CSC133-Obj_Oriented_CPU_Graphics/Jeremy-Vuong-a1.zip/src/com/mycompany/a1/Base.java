package com.mycompany.a1;

public class Base extends Fixed {
	private int sequenceNumber;

	public Base(final int objSize, final double locX, final double locY, final int objColor, int objSequenceNumber) 
	{
		super(objSize, locX, locY, objColor);
		this.sequenceNumber = objSequenceNumber;
		// TODO Auto-generated constructor stub
	}
	
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " seqNum=" + sequenceNumber;
		return parentDesc + myDesc;
	}

}